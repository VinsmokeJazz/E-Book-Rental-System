<?php
session_start();
if ($_SESSION["admid"] == NULL){
	header('location: register.php');
}

if(isset($_POST["submit"])){
	$id = $_POST['bookid'];
	$bookname=$_POST['txtBook'];
	$category=$_POST['txtCategory'];
	$course=$_POST['txtCourse'];
	$author=$_POST['txtAuthor']; 
	$price=$_POST['txtPrice']; 
	$stock = $_POST['txtStock'];
	$bookdesc=$_POST['txtbookdesc'];
	$keywords=$_POST['txtkeywords'];

	// $folder="book_images/";
	// $book_image = $_FILES['txtFile']['name'];
	// $ext = substr($book_image, strpos($book_image,'.'), strlen($book_image)-1); // Get the extension from the filename.
 //    $file_loc = $_FILES['txtFile']['tmp_name'];

 //    if(file_exists($folder.$book_image)) 
 //    	unlink($folder.$book_image);

 //   	move_uploaded_file($file_loc,$folder.$book_image);

	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "bookrent";
	try{
		$pdo = new PDO("mysql:host=$servername;dbname=$dbname", "$username", "$password");
			// Set the PDO error mode to exception
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

			//


		$sql=$pdo->prepare("SELECT * FROM tblwishlist WHERE bookid=:bookid");
		$sql->execute(["bookid"=>$id]);
		$row=$sql->fetch();
		$pstatus = $row['status'];
		$prvstatus = $row['prvstatus'];

			//updating the table
		$sql = "UPDATE tblbooks SET bookname=:bookname,author=:author, price=:price, stock=:stock,category=:category,course=:course,bookdesc=:bookdesc,book_keywords=:keywords WHERE bookid=:bookid";
		$query = $pdo->prepare($sql);			
		$query->bindparam(':bookid', $id);
		$query->bindparam(':bookname', $bookname);
		$query->bindparam(':author', $author);
		$query->bindparam(':price', $price);
		$query->bindparam(':stock', $stock);
		$query->bindparam(':category', $category);
		$query->bindparam(':course', $course);
		$query->bindparam(':bookdesc', $bookdesc);
		$query->bindparam(':keywords', $keywords);


		$res = $query->execute();
		if($res > 0){
			$sql=$pdo->prepare("SELECT * FROM tblbooks WHERE bookid=:bookid");
			$sql->execute(["bookid"=>$id]);
			$row=$sql->fetch();
			$stock = $row['stock'];
			if( $stock > 0 ){
				$status = 1;
				$prevstatus = $pstatus;
			} 

			$sql1 = "UPDATE tblwishlist SET status=:status, prvstatus=:prvstatus where bookid=:bookid";
			$query1 = $pdo->prepare($sql1);
			$query1->bindparam(':bookid', $id);
			$query1->bindparam(':status', $status); 
			$query1->bindparam(':prvstatus', $prevstatus);
			$query1->execute();

			header("Location:viewbooks.php?upd=1");
		}else{
			echo "<h2>Something went wrong.. Try again..!</h2>";
		}
			//header("Location:admincareer.php");	
	}catch(PDOException $e) {
		echo "Error: " . $e->getMessage();
	}
}
?>
