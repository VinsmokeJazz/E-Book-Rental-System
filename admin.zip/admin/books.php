<!doctype html>
<html lang="en">
<?php
    include('header.php');
?>
<body>

<div class="wrapper">
    <div class="sidebar" data-color="azure" data-image="assets/img/sidebar-4.jpg">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

        <div class="sidebar-wrapper">
            <div class="logo">
                <a href="dashboard.php" class="simple-text">
                    E-Book_Rental | Admin
                </a>
            </div>

            <ul class="nav">
                <li>
                    <a href="index.php">
                        <i class="pe-7s-user"></i>
                        <p>Users</p>
                    </a>
                </li>
                <li>
                    <a href="category_course.php">
                        <i class="pe-7s-note2"></i>
                        <p>Add Category & Course</p>
                    </a>
                </li>
                <li class="active">
                    <a href="books.php">
                        <i class="pe-7s-notebook"></i>
                        <p>Add Books</p>
                    </a>
                </li>
                <li>
                    <a href="viewbooks.php">
                        <i class="pe-7s-display2"></i>
                        <p>View Books</p>
                    </a>
                </li>
                <li>
                    <a href="viewusers.php">
                        <i class="pe-7s-users"></i>
                        <p>View Users</p>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <div class="main-panel">
		<nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Manage Books</a>
                </div>
                <div class="collapse navbar-collapse">
                    <!-- <ul class="nav navbar-nav navbar-left">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-dashboard"></i>
								<p class="hidden-lg hidden-md">Dashboard</p>
                            </a>
                        </li>
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="fa fa-globe"></i>
                                    <b class="caret hidden-sm hidden-xs"></b>
                                    <span class="notification hidden-sm hidden-xs">5</span>
									<p class="hidden-lg hidden-md">
										5 Notifications
										<b class="caret"></b>
									</p>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Notification 1</a></li>
                                <li><a href="#">Notification 2</a></li>
                                <li><a href="#">Notification 3</a></li>
                                <li><a href="#">Notification 4</a></li>
                                <li><a href="#">Another notification</a></li>
                              </ul>
                        </li>
                        <li>
                           <a href="">
                                <i class="fa fa-search"></i>
								<p class="hidden-lg hidden-md">Search</p>
                            </a>
                        </li>
                    </ul> -->

                    <ul class="nav navbar-nav navbar-right">
                        <!-- <li>
                           <a href="">
                               <p>Account</p>
                            </a>
                        </li> -->
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <p>
										Manage
										<b class="caret"></b>
									</p>

                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="viewbooks.php">Edit Books</a></li>
                                <li><a href="viewbooks.php">Delete Books</a></li>
                                
                                <!-- <li class="divider"></li>
                                <li><a href="#">Separated link</a></li> -->
                              </ul>
                        </li> 
                        <li>
                            <a href="logout.php">
                                <p>Log out</p>
                            </a>
                        </li>
						<li class="separator hidden-lg hidden-md"></li>
                    </ul>
                </div>
            </div>
        </nav>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-10">
                    <?php
                            if(isset($_POST["submit"])){
                                $catname = $_POST["txtCategory"];
                                $coursename = $_POST["txtCourse"];
                                $bookname = $_POST["txtBook"];
                                $author = $_POST["txtAuthor"];
                                $price = $_POST["txtPrice"];
                                $stocks = $_POST["txtStock"];
                                $bookdesc= $_POST["txtbookdesc"];
                                $keywords= $_POST["txtkeywords"];

                                $allowed_filetypes = array('.jpg');
                                $folder="./book_images/";

                                $book_image = $_FILES['txtFile']['name'];
                                $ext = substr($book_image, strpos($book_image,'.'), strlen($book_image)-1); // Get the extension from the filename.
                                $file_loc = $_FILES['txtFile']['tmp_name'];
                                // $file_size = $_FILES['txtFile']['size'];
                                // $file_type = $_FILES['txtFile']['type'];
                                  // Check if the filetype is allowed, if not DIE and inform the user.
   // if(!in_array($ext,$allowed_filetypes))
   //    die('The file you attempted to upload is not allowed.');
                                
                                move_uploaded_file($file_loc,$folder.$book_image);
                
                                $servername = "localhost";
                                $username = "root";
                                $password = "";
                                $dbname = "bookrent";

                                try{
                                    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                                    // set the PDO error mode to exception
                                    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                                    $stmt = $conn->prepare("INSERT INTO tblbooks 
                                        (bookid,bookname,bookimage,author,price,stock,category,course,bookdesc,book_keywords) 
                                        VALUES (NULL,:bookname,:bookimage,:author,:price,:stock,:category,:course,:bookdesc,:book_keywords)");
                                    $stmt->bindParam(':bookname',$bookname);
                                    $stmt->bindParam(':bookimage',$book_image);
                                    $stmt->bindParam(':author',$author);
                                    $stmt->bindParam(':price',$price);
                                    $stmt->bindParam(':stock',$stocks);
                                    $stmt->bindParam(':category',$catname);
                                    $stmt->bindParam(':course',$coursename);
                                    $stmt->bindParam(':bookdesc',$bookdesc);
                                    $stmt->bindParam(':book_keywords',$keywords);
                                    $result = $stmt->execute();
                                        
                                    if($result > 0){ 
                        ?>
                                        <div >
                                            <div class="alert alert-success alert-dismissable fade in">
                                                <a href="books.php" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                <strong>Success!</strong> <p align="center" style="font-family: cursive;color: black">Book is added..!</p>
                                            </div>
                                        </div>
                        <?php 
                                    } else {  
                        ?>
                                        <div class="alert alert-warning alert-dismissable fade in">
                                            <a href="books.php" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                            <strong>Warning!</strong> <p align="center" style="font-family: cursive;color: black">Something went wrong !</p>
                                        </div> 
                        <?php   
                                    }  
                                }catch(PDOException $e){
                                    echo "ERROR: ".$e->getMessage();
                                }
                                $conn = null; 
                            } 
                        ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-10">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Add Book</h4>
                            </div>
                            <div class="content">
                                <form action="<?php echo $_SERVER["PHP_SELF"] ?>" method="post" enctype="multipart/form-data">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Category name</label>
                                                <select class="form-control" id="txtCategory" name="txtCategory" onchange="changecourse(this.value);">
                                                    <?php
                                                        $servername = "localhost";
                                                        $username = "root";
                                                        $password = "";
                                                        $dbname = "bookrent";

                                                        try{
                                                            $conn = new PDO("mysql:host=$servername;dbname=$dbname",$username,$password);
                                                            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                                                            $stmt = $conn->prepare("SELECT distinct(categoryid),categoryname FROM tblcategory group by categoryname");
                                                            $stmt->execute();
                                                            echo "<option selected disabled>Select Category</option>";
                                                            while($res=$stmt->fetch(PDO::FETCH_ASSOC)){
                                                                $categoryid= $res['categoryid'];
                                                                echo "<option value='$categoryid'>".$res['categoryname']."</option>";
                                                            } 
                                                        }catch(PDOException $e){
                                                            echo "ERROR: ".$e->getMessage();
                                                        }
                                                        $conn = null; 
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <script type="text/javascript">
                                            function changecourse(val)
                                            {
                                                $.ajax({
                                                    type: 'post',
                                                    url: 'course.php',
                                                    data: {
                                                        get_option:val
                                                    },
                                                    success: function (response) {
                                                        document.getElementById("course").innerHTML=response; 
                                                    }
                                                });
                                            }
                                        </script>

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Course name</label>
                                                
                                                <select class="form-control" id="course" name="txtCourse">
                                                    <!-- Course.php -->
                                                </select> 
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Book name</label>
                                                <input type="text" class="form-control" placeholder="Book name" name="txtBook" required="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="job">Book Description</label>
                                                <textarea name="txtbookdesc" id="txtbookdesc" class="form-control" rows="5" required="required" placeholder="Book Description"></textarea>
                                            </div> 
                                        </div> 
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Author</label>
                                                <input type="text" class="form-control" placeholder="Author" name="txtAuthor" required="">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Price in Rs.</label>
                                                <input type="text" class="form-control" placeholder="Price in Rs." name="txtPrice" required="">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Image Upload</label> 
                                                <input type="file" name="txtFile" id="txtFile" required >
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Keywords</label>
                                                <input type="text" class="form-control" placeholder="Keywords" name="txtkeywords" required="">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Stocks Available</label>
                                                <input type="text" class="form-control" placeholder="How many books" name="txtStock" required="">
                                            </div>
                                        </div>
                                         <div class="col-md-3">
                                            <div style="text-align: center;"> 
                                                <input type="submit" name="submit" class="btn btn-info btn-fill hvr-grow" style="margin-top: 23px;width: 80%;background-color:  #9368e9;border:  none;" value="ADD"/>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-5">
                        
                    </div>

                </div>
            </div>
        </div>

        <footer class="footer">
            <div class="container-fluid">
                <?php
                    include('footer.php');
                ?>
            </div>
        </footer>

    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script type="text/javascript">
        window.setTimeout(function () {
            $(".alert-success").fadeTo(500, 0).slideUp(500, function () {
                $(this).remove();
            });
        }, 1000);

    </script>
    <script src="assets/js/jquery.3.2.1.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>
    
</html>
