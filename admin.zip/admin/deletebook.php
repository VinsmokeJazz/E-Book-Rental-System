<?php
	session_start();
    if ($_SESSION["admid"] == NULL){
        header('location: register.php');
    }

	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "bookrent";
		try{
			$pdo = new PDO("mysql:host=$servername;dbname=$dbname", "$username", "");
			// Set the PDO error mode to exception
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			 
			$id = $_GET['bookid'];
								
			//deleting the row from table
			$sql = "DELETE FROM tblbooks WHERE bookid=:id";
			$query = $pdo->prepare($sql);
			$res = $query->execute(array(':id' => $id));
			//$res=$stmt->execute();
			if($res > 0){
				header("Location:viewbooks.php?del=1");
			}
				
		} catch(PDOException $e){
			die("ERROR: Could not connect. " . $e->getMessage());
		}
?>