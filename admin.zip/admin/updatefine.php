<?php
session_start();
if ($_SESSION["admid"] == NULL){
	header('location: register.php');
}

if(isset($_POST["submit"])){
	$challanid = $_POST['challanid'];
	$userid=$_POST['userid'];
	$fine=$_POST['txtFine'];

	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "bookrent";
	try{
		$pdo = new PDO("mysql:host=$servername;dbname=$dbname", "$username", "$password");
			// Set the PDO error mode to exception
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

			//updating the table
		$sql = "UPDATE tblchallan SET fine_status=:fine WHERE userid=:userid AND challanid=:challanid";
		$query = $pdo->prepare($sql);			

		$query->bindparam(':fine', $fine);
		$query->bindparam(':userid', $userid);
		$query->bindparam(':challanid', $challanid);

		$res = $query->execute();
		if($res > 0){
			header("Location:index.php?upd=1");
		}else{
			echo "<h2>Something went wrong.. Try again..!</h2>";
		}
			//header("Location:admincareer.php");	
	}catch(PDOException $e) {
		echo "Error: " . $e->getMessage();
	}
}

?>
