<?php
session_start();
if ($_SESSION["admid"] == NULL){
	header('location: register.php');
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bookrent";
try{
	$pdo = new PDO("mysql:host=$servername;dbname=$dbname", "$username", "");
			// Set the PDO error mode to exception
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

	$id = $_GET['userid'];
	$chalid = $_GET['challanid'];

	$sql=$pdo->prepare("SELECT return_status FROM tblchallan WHERE userid=:userid and challanid=:challanid");
	$sql->bindParam(":userid",$id);
	$sql->bindParam(":challanid",$chalid);
	$sql->execute();
	$row=$sql->fetch();
	$return_status = $row['return_status'];
	if($return_status == 0){
		$sql1=$pdo->prepare("SELECT b.bookid,o.bookid,o.userid,o.qty,o.challanid,b.stock FROM tblorderbook o,tblbooks b WHERE b.bookid=o.bookid AND o.userid=:userid AND o.challanid=:challanid");
		$sql1->bindParam(":userid",$id);
		$sql1->bindParam(":challanid",$chalid);
		$sql1->execute();

		while($row=$sql1->fetch()){
			$stock=$row['stock'];
			$qty=$row['qty'];
			$bookid=$row['bookid'];
			$return_status=$row['return_status'];


			$stock=$stock+$qty;

			$sql2=$pdo->prepare("UPDATE tblbooks SET stock=:stock WHERE bookid=:bookid");
			$sql2->bindParam(":stock",$stock);
			$sql2->bindParam(":bookid",$bookid);
			$result1=$sql2->execute();
		}
	}


	$sql = "DELETE FROM tblchallan WHERE userid=:id and challanid=:challanid";
	$query = $pdo->prepare($sql);
	$res = $query->execute(array(':id' => $id,':challanid'=>$chalid));

	$sql = "DELETE FROM tblorderbook WHERE userid=:id and challanid=:challanid";
	$query = $pdo->prepare($sql);
	$res = $query->execute(array(':id' => $id,':challanid'=>$chalid));
			//$res=$stmt->execute();

	if($res > 0){
		header("Location:index.php");
	}


} catch(PDOException $e){
	die("ERROR: Could not connect. " . $e->getMessage());
}
?>