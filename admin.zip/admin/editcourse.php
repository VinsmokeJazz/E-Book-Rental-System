<?php
session_start();
        if ($_SESSION["admid"] == NULL){
            header('location: register.php');
        }
        
if(isset($_POST['get_option']))
{
                                                        // $cat = "<script>document.getElementById('txtCategory').value</script>";
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "bookrent";
    
    try{
        $cat = $_POST['get_option'];
        $coursename=$_POST['coursename'];
        $conn = new PDO("mysql:host=$servername;dbname=$dbname",$username,$password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT distinct(courseid),coursename FROM tblcourse WHERE category=:categoryid");
        $stmt->bindParam(':categoryid', $cat);
        $stmt->execute();
        // $courseid=$res['courseid'];
        // echo "<option>$coursename</option>";
        while($res=$stmt->fetch(PDO::FETCH_ASSOC)){
            if($courseid != $res['courseid']){
                $crsid=$res['courseid'];
                echo "<option value='$crsid'>".$res['coursename']."</option>";
            }
        } 
    }catch(PDOException $e){
        echo "ERROR: ".$e->getMessage();
    }
    $conn = null;
} 
?>