<!doctype html>
<html lang="en">
<?php
    include('header.php');
?>
<body>

<div class="wrapper">
    <div class="sidebar" data-color="orange" data-image="assets/img/sidebar-4.jpg">
        <div class="sidebar-wrapper">
            <div class="logo">
                <a href="dashboard.php" class="simple-text">
                    E-Book_Rental | Admin
                </a>
            </div>

            <ul class="nav">
                <li>
                    <a href="index.php">
                        <i class="pe-7s-user"></i>
                        <p>Users</p>
                    </a>
                </li>
                <li>
                    <a href="category_course.php">
                        <i class="pe-7s-note2"></i>
                        <p>Add Category & Course</p>
                    </a>
                </li>
                <li>
                    <a href="books.php">
                        <i class="pe-7s-notebook"></i>
                        <p>Add Books</p>
                    </a>
                </li>
                <li>
                    <a href="viewbooks.php">
                        <i class="pe-7s-display2"></i>
                        <p>View Books</p>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <div class="main-panel">
		<nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="logout.php">
                                <p>Log out</p>
                            </a>
                        </li>
						<li class="separator hidden-lg hidden-md"></li>
                    </ul>
                </div>
            </div>
        </nav>

        <?php
        error_reporting(0);
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "bookrent";
        try{
            $pdo = new PDO("mysql:host=$servername;dbname=$dbname", "$username","$password");
            // Set the PDO error mode to exception
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            //getting id from url
            $challanid = $_GET['chalid'];
            $userid=$_GET['uid'];
     
            $sql=$pdo->prepare("SELECT u.name,c.fine_status FROM tblchallan c,tblusers u WHERE c.challanid=:challanid AND u.userid=:userid");
            $sql->bindParam(":challanid",$challanid);
            $sql->bindParam(":userid",$userid);
            $sql->execute();
            while ($row=$sql->fetch()) {
                $name=$row['name'];
                $fine_status=$row['fine_status'];
            }

        }catch(PDOException $e){
            echo "ERROR: ".$e->getMessage();
        }
        $conn = null; 
    ?>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-10">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Manage Fine Details</h4>
                            </div>
                            <div class="content">
                                <form action="updatefine.php" method="post" enctype="multipart/form-data">
                                    <input type="hidden" name="challanid" id="challanid" value=<?php echo $challanid;?> />
                                     <input type="hidden" name="userid" id="userid" value=<?php echo $userid;?> />
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Challan Number</label>
                                                <input type="text" disabled="" class="form-control" placeholder="Challan number" name="txtChallan" required="" value=<?php echo $challanid ?>>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>User Name</label>
                                                <input type="text" class="form-control" disabled placeholder="User name" name="txtUser" required="" value=<?php echo $name ?>>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Fine</label>
                                                <input type="text" class="form-control" placeholder="Pay Fine" name="txtFine" required="" value=<?php echo $fine_status ?>>
                                            </div>
                                        </div>
                                    </div>
                                        
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div > 
                                                <input type="submit" name="submit" class="btn btn-info btn-fill hvr-grow" style="margin-top: 1px;" value="UPDATE"/>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <!--  -->
                    </div>

                </div>
            </div>
        </div>

        <footer class="footer">
            <div class="container-fluid">
                <?php
                    include('footer.php');
                ?>
            </div>
        </footer>

    </div>
</div>
</body>

    <!--   Core JS Files   -->
    <script type="text/javascript">
        window.setTimeout(function () {
            $(".alert-success").fadeTo(500, 0).slideUp(500, function () {
                $(this).remove();
            });
        }, 1000);

    </script>
    <script src="assets/js/jquery.3.2.1.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>
    
</html>
