<!doctype html>
<html lang="en">
<body>
	<p class="copyright pull-right">
		&copy; <script>document.write(new Date().getFullYear())</script> | E-BookRental, Online Book Store
    </p>
</body>
</html>