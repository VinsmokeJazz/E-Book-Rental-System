<!doctype html>
<html lang="en">
<?php
include('header.php');
?>
<body>

    <div class="wrapper">
        <div class="sidebar" data-color="orange" data-image="assets/img/sidebar-4.jpg">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

    <div class="sidebar-wrapper">
        <div class="logo">
            <a href="dashboard.php" class="simple-text">
                E-Book_Rental | Admin
            </a>
        </div>

        <ul class="nav">
                <!-- <li >
                    <a href="dashboard.php">
                        <i class="pe-7s-graph"></i>
                        <p>Dashboard</p>
                    </a>
                </li> -->
                <li class="active">
                    <a href="index.php">
                        <i class="pe-7s-user"></i>
                        <p>Users</p>
                    </a>
                </li>
                <li>
                    <a href="category_course.php">
                        <i class="pe-7s-note2"></i>
                        <p>Add Category & Course</p>
                    </a>
                </li>
                <li >
                    <a href="books.php">
                        <i class="pe-7s-notebook"></i>
                        <p>Add Books</p>
                    </a>
                </li>
                <li>
                    <a href="viewbooks.php">
                        <i class="pe-7s-display2"></i>
                        <p>View Books</p>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <div class="main-panel">
      <nav class="navbar navbar-default navbar-fixed">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">User Details</a>
            </div>
            <div class="collapse navbar-collapse">
                <ul class="nav navbar-nav navbar-right">
                        <!-- <li>
                           <a href="">
                               <p>Account</p>
                            </a>
                        </li> -->

                        <li>
                            <a href="logout.php">
                                <p>Log out</p>
                            </a>
                        </li>
                        <li class="separator hidden-lg hidden-md"></li>
                    </ul>
                </div>
            </div>
        </nav>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-10">
                        <?php
                        $userid=$_GET['userid'];
                        $challanid=$_GET['challanid'];
                        // echo $userid;

                        $servername = "localhost";
                        $username = "root";
                        $password = "";
                        $dbname = "bookrent";
                        try{
                            $pdo = new PDO("mysql:host=$servername;dbname=$dbname", "$username", "$password");
                                                                // Set the PDO error mode to exception
                            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                        }catch(PDOException $e){
                            die("ERROR: Could not connect. " . $e->getMessage());
                        }

                        $sql=$pdo->prepare("SELECT name,phone,address,email FROM tblusers where userid=:userid");
                        $sql->bindParam(":userid",$userid);
                        $sql->execute();
                        while($row=$sql->fetch()){
                            $name=$row['name'];
                            $email=$row['email'];
                            $address=$row['address'];
                            $phone=$row['phone'];
                        }
                        ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-3"></div>
                    <div class="col-md-6">
                        <div class="card">
                            <!-- <div class="header">
                                <h3 class="title">USER DETAILS</h3>
                            </div> -->
                            <div class="content">
                                <div>
                                    <div class="row">
                                        <div class="col-md-12" >
                                            <h4 >Name : <?php echo $name; ?></h4>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <h4>Address : <?php echo $address; ?></h4>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <h4>Phone : <?php echo $phone; ?></h4>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <h4>Email ID : <?php echo $email; ?></h4>
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row">
                                        <div class="col-md-3"> 
                                            <a href="index.php" class='btn btn-primary hvr-grow'>Back</a>
                                        </div>

                                        <div class="col-md-3"> 
                                            <a href="deleteuser.php?userid=<?php echo $userid ?>&challanid=<?php echo $challanid ?>" class='btn btn-danger hvr-grow' onClick="return confirm('Are you sure you want to delete?')">Delete</a>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3"></div>
                </div>

            </div>
        </div>
        </div>
    </div>


    </body>

    <script src="assets/js/jquery.3.2.1.min.js" type="text/javascript"></script>
    <script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

    <!--  Charts Plugin -->
    <script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
    <script src="assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>

    <!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
    <script src="assets/js/demo.js"></script>

    </html>
