
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bookrent";
try{
	$pdo = new PDO("mysql:host=$servername;dbname=$dbname", "$username", "$password");
                                                            // Set the PDO error mode to exception
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}catch(PDOException $e){
	die("ERROR: Could not connect. " . $e->getMessage());
}
if(isset($_POST["search"]) ) {
	// error_reporting(0);
	try{
		$keywords = $_POST["keywords"];
		$sql = $pdo->prepare("SELECT u.userid,u.name,u.phone,b.bookid,b.bookname,b.bookimage,o.userid,o.bookid,o.qty,o.challanid,c.totalamount,c.appointment_date,c.return_date,c.time_slot,c.start_date,c.end_date,c.paid_status,c.return_status,c.fine_status FROM tblbooks b,tblusers u,tblorderbook o,tblchallan c WHERE b.bookid=o.bookid AND c.challanid=o.challanid AND u.userid=c.userid AND (u.name LIKE :namekeywords OR o.challanid LIKE :challankeywords) group by (c.challanid)");
		$sql->execute(array(':namekeywords' => "%".$keywords."%" , ':challankeywords' => "%".$keywords."%" ));  
		if($sql->rowCount() > 0){
			echo"<div class='content table-responsive table-full-width'>";
			echo "<table class='table table-hover table-striped'><thead><th>Challan</th><th>Name</th>
			<th style='width: 250px;'>Book Details</th><th>Amount</th><th>Appointment</th><th>Time Slot</th><th>Return Date</th><th>Payment</th><th>Return</th><th>Fine</th></thead>";
			while($row = $sql->fetch()){  
				$userID=$row['userid'];   
				$challanid=$row['challanid'];
				$paid_status=$row['paid_status'];
				$return_status=$row['return_status'];
				$fine=$row['fine_status'];

				$currentdate=date("Y-m-d");
				$appointment_date=$row["appointment_date"];
				$end_date=$row['end_date'];
				$start_date=$row['start_date'];

				$ReturnDate = $row['return_date'];

				$NextEndDate = date('Y-m-d', strtotime("+1 month", strtotime($end_date)));

				if(($currentdate > $end_date) && ($currentdate <= $NextEndDate) && ($paid_status == 0) ){
					// echo "<tr style='background-color:#00808052;' class='row-$challanid' chalid='$challanid'>";
					echo "<tr style='background-color:00808052;' class='row-$challanid' chalid='$challanid'>";
				}else if(($currentdate > $ReturnDate) && ($return_status == 0) ){

					$fine=$fine+20;
					$ReturnDate = date('Y-m-d', strtotime("+7 days", strtotime($ReturnDate)));
					$sql = "UPDATE tblchallan SET fine_status=:fine,return_date=:ReturnDate WHERE userid=:userid AND challanid=:challanid";
					$query = $pdo->prepare($sql);			

					$query->bindparam(':fine', $fine);
					$query->bindparam(':ReturnDate', $ReturnDate);              
					$query->bindparam(':userid', $userID);
					$query->bindparam(':challanid', $challanid);

					$res = $query->execute();
					//echo "<tr style='background-color:pink;' class='row-$challanid' chalid='$challanid'>";
					
				}else{
					echo "<tr style='background-color:none;' class='row-$challanid' chalid='$challanid'>";
				}

				echo "<td>".$row["challanid"]."</td><td><a href='userdetails.php?userid=$userID&challanid=$challanid' class='text-primary'>".$row["name"]."</a></td>";
				$sql1=$pdo->prepare("SELECT b.bookid,b.bookname,b.price,o.userid,o.bookid,o.qty,o.challanid,o.totalamount,c.challanid FROM tblbooks b,tblusers u,tblorderbook o,tblchallan c WHERE b.bookid=o.bookid AND o.userid=:userid AND o.challanid=:challanid group by(b.bookname)");
				$sql1->bindParam(":userid",$userID);
				$sql1->bindParam(":challanid",$challanid);
				$sql1->execute();
				echo "<td>";
				while($row1 = $sql1->fetch()){     
					echo $row1["bookname"].", <b>Qty</b> = ".$row1["qty"]."<br>";
				}
				echo "</td>";
				echo "<td>".$row["totalamount"]."</td>";
				echo "<td>$appointment_date</td><td>".$row["time_slot"]."</td><td>$ReturnDate</td>";
				if($paid_status == 0){
					echo "<td><button type='button' chalid='$challanid' class='btn btn-primary paid-$challanid hvr-grow' id='paid'><span style='color:red' class='fa fa-times'></span></button></td>";
				}else{
					echo "<td><button type='button' disabled chalid='$challanid' class='btn btn-primary paid-$challanid hvr-grow' id='paid'><span style='color:green' class='fa fa-check'></span></button></td>";
				}
				if($return_status == 0){
					echo "<td><button type='button' chalid='$challanid' userid='$userID'  class='btn btn-primary return-$challanid hvr-grow' id='return'><span style='color:red' class='fa fa-times'></span></button></td>";
					// echo "<td><a href='fine.php?chalid=$challanid&uid=$userID' chalid='$challanid' class='btn btn-danger fine-$challanid hvr-grow'>Rs.$fine</a></td>";
					echo "<td style=color:red class='fine-$challanid '><b>Rs. $fine /-</b></td>";
				}else{
					echo "<td><button type='button' disabled chalid='$challanid' class='btn btn-primary return-$challanid hvr-grow' id='return'><span style='color:green' class='fa fa-check'></span></button></td>";
				}

				echo "</tr>";
			}
			echo "</table>";
			echo "</div>";
		} else {
			echo "<h3 style='text-align: center;'>No User Details</h3>";
		}

	} catch(PDOException $e){
		die("ERROR: Could not able to execute $sql. " . $e->getMessage());
	}
}

if(isset($_POST["all"]) ) {
	// $date = date_default_timezone_set('Asia/Kolkata');
	ini_set('date.timezone', 'Asia/Kolkata');
	try{
		$sql = "SELECT u.userid,u.name,u.phone,b.bookid,b.bookname,b.bookimage,o.userid,o.bookid,o.qty,o.challanid,c.totalamount,c.appointment_date,c.return_date,c.time_slot,c.start_date,c.end_date,c.paid_status,c.return_status,c.fine_status FROM tblbooks b,tblusers u,tblorderbook o,tblchallan c WHERE b.bookid=o.bookid AND c.challanid=o.challanid AND u.userid=c.userid group by (c.challanid)";  
		$result = $pdo->query($sql);
		if($result->rowCount() > 0){
			echo"<div class='content table-responsive table-full-width'>";
			echo "<table class='table table-hover table-striped'><thead><th>Challan</th><th>Name</th>
			<th style='width: 250px;'>Book Details</th><th>Amount</th><th>Appointment</th><th>Time Slot</th><th>Return Date</th><th>Payment</th><th>Return</th><th>Fine</th></thead>";
			
			while($row = $result->fetch()){  
				$userID=$row['userid'];   
				$challanid=$row['challanid'];
				$paid_status=$row['paid_status'];
				$return_status=$row['return_status'];
				$fine=$row['fine_status'];

				$currentdate=date("Y-m-d");
				$end_date=$row['end_date'];
				$start_date=$row['start_date'];
				$appointment_date=$row["appointment_date"];
				$ReturnDate = $row['return_date'];

				$NextEndDate = date('Y-m-d', strtotime("+1 month", strtotime($end_date)));

				if(($currentdate > $end_date) && ($currentdate <= $NextEndDate) && ($paid_status == 0) ){
					// echo "<tr style='background-color:#00808052;' class='row-$challanid' chalid='$challanid'>";
					echo "<tr style='background-color:pink;' class='row-$challanid' chalid='$challanid'>";
				}else if(($currentdate > $ReturnDate) && ($return_status == 0) ){

					$fine=$fine+20;
					$ReturnDate = date('Y-m-d', strtotime("+7 days", strtotime($ReturnDate)));
					$sql = "UPDATE tblchallan SET fine_status=:fine,return_date=:ReturnDate WHERE userid=:userid AND challanid=:challanid";
					$query = $pdo->prepare($sql);			

					$query->bindparam(':fine', $fine);
					$query->bindparam(':ReturnDate', $ReturnDate);              
					$query->bindparam(':userid', $userID);
					$query->bindparam(':challanid', $challanid);

					$res = $query->execute();
					
				}else{
					echo "<tr style='background-color:none;' class='row-$challanid' chalid='$challanid'>";
				}
				
				echo "<td>".$row["challanid"]."</td><td><a href='userdetails.php?userid=$userID&challanid=$challanid' class='text-primary'>".$row["name"]."</a></td>";

				$sql1=$pdo->prepare("SELECT b.bookid,b.bookname,b.price,o.userid,o.bookid,o.qty,o.challanid,o.totalamount,c.challanid FROM tblbooks b,tblusers u,tblorderbook o,tblchallan c WHERE b.bookid=o.bookid AND o.userid=:userid AND o.challanid=:challanid group by(b.bookname)");
				$sql1->bindParam(":userid",$userID);
				$sql1->bindParam(":challanid",$challanid);
				$sql1->execute();
				echo "<td>";
				while($row1 = $sql1->fetch()){     
					echo $row1["bookname"].", <b>Qty</b> = ".$row1["qty"]."<br>";
				}
				echo "</td>";
				echo "<td>".$row["totalamount"]."</td>";
				echo "<td>$appointment_date</td><td>".$row["time_slot"]."</td><td>$ReturnDate</td>";
				if($paid_status == 0){
					echo "<td><button type='button' chalid='$challanid' class='btn btn-primary paid-$challanid hvr-grow' id='paid'><span style='color:red' class='fa fa-times'></span></button></td>";
				}else{
					echo "<td><button type='button' disabled chalid='$challanid' class='btn btn-primary paid-$challanid hvr-grow' id='paid'><span style='color:green' class='fa fa-check'></span></button></td>";
				}
				if($return_status == 0){
					echo "<td><button type='button' chalid='$challanid' userid='$userID'  class='btn btn-primary return-$challanid hvr-grow' id='return'><span style='color:red' class='fa fa-times'></span></button></td>";
					// echo "<td><a href='fine.php?chalid=$challanid&uid=$userID' chalid='$challanid' class='btn btn-danger fine-$challanid hvr-grow'>Rs.$fine</a></td>";
					echo "<td style=color:red class='fine-$challanid '><b>Rs. $fine /-</b></td>";
				}else{
					echo "<td><button type='button' disabled chalid='$challanid' class='btn btn-primary return-$challanid hvr-grow' id='return'><span style='color:green' class='fa fa-check'></span></button></td>";
				}
				// echo "<td>$currenttime</td>";
				echo "</tr>";
			}
			echo "</table>";
			echo "</div>";
		} else {
			echo "<h3 style='text-align: center;'>No User Details</h3>";
		}

	} catch(PDOException $e){
		die("ERROR: Could not able to execute $sql. " . $e->getMessage());
	}
}

if(isset($_POST['paidchallan'])){
	$challanid=$_POST['challanid'];

	$sql=$pdo->prepare("UPDATE tblchallan SET paid_status=:paid WHERE challanid=:challanid");
	$sql->bindValue(":paid",1);
	$sql->bindParam(":challanid",$challanid);
	$result=$sql->execute();
	if($result > 0){
		print 1;
	}else{
		print 0;
	}
}

if(isset($_POST['returnstatus'])){
	$challanid=$_POST['challanid'];
	$userid=$_POST['userid'];

	$sql1=$pdo->prepare("SELECT b.bookid,o.bookid,o.userid,o.qty,o.challanid,b.stock FROM tblorderbook o,tblbooks b WHERE b.bookid=o.bookid AND o.userid=:userid AND o.challanid=:challanid");
	$sql1->bindParam(":userid",$userid);
	$sql1->bindParam(":challanid",$challanid);
	$sql1->execute();

	while($row=$sql1->fetch()){
		$stock=$row['stock'];
		$qty=$row['qty'];
		$bookid=$row['bookid'];

		$stock=$stock+$qty;

		$sql2=$pdo->prepare("UPDATE tblbooks SET stock=:stock WHERE bookid=:bookid");
		$sql2->bindParam(":stock",$stock);
		$sql2->bindParam(":bookid",$bookid);
		$result1=$sql2->execute();
	}

	$sql=$pdo->prepare("UPDATE tblchallan SET return_status=:return,fine_status=:fine WHERE challanid=:challanid");
	$sql->bindValue(":return",1);
	$sql->bindValue(":fine",0);
	$sql->bindParam(":challanid",$challanid);
	$result=$sql->execute();
	if($result > 0){
		print 1;
	}else{
		print 0;
	}
}

if(isset($_POST['allbooks'])){
	try{
		$sql = "SELECT b.bookid,b.category,b.course,b.bookname,b.bookimage,b.author,b.price,b.stock,c.courseid,c.coursename,cat.categoryid,cat.categoryname FROM tblbooks b,tblcategory cat,tblcourse c WHERE b.category=cat.categoryid AND b.course=c.courseid";   
		$result = $pdo->query($sql);
		if($result->rowCount() > 0){
			echo"<div class='content table-responsive table-full-width'>";
			echo "<table class='table table-hover table-striped'><thead><th>Category</th><th>Course</th><th>Book Name</th><th>Image</th><th>Author</th><th>Price</th><th>Stocks</th><th>Edit Book</th><th>Delete Book</th></thead>";
			while($row = $result->fetch()){     
				echo "<tr><td>".$row["categoryname"]."</td><td>".$row["coursename"]." </td><td>".$row["bookname"]."</td>";
				echo "<td><img src='book_images/".$row['bookimage']."' height='100px'/></td>";
				echo "<td>".$row["author"]."</td><td>". $row['price']."</td><td>".$row["stock"]."</td> ";
				echo "<td><a href=\"editbook.php?bookid=$row[bookid]\" class='btn btn-primary hvr-grow' >Edit</a></td>";
				echo "<td><a href=\"deletebook.php?bookid=$row[bookid]\" class='btn btn-danger hvr-grow' onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";
			}
			echo "</table>";
			echo "</div>";
		} else {
			echo "<h3 style='text-align: center;'>No Book Details</h3>";
		}
	} catch(PDOException $e){
		die("ERROR: Could not able to execute $sql. " . $e->getMessage());
	}
}

if(isset($_POST['searchbooks'])){
	try{
		$keywords=$_POST['keywords'];
		$sql = $pdo->prepare("SELECT b.bookid,b.category,b.course,b.bookname,b.bookimage,b.author,b.price,b.stock,b.book_keywords,c.courseid,c.coursename,cat.categoryid,cat.categoryname FROM tblbooks b,tblcategory cat,tblcourse c WHERE b.category=cat.categoryid AND b.course=c.courseid AND (b.bookname LIKE :bookname_keyword OR c.coursename LIKE :course_keyword OR b.author LIKE :author_keyword OR b.book_keywords LIKE :bookkeywords_keyword OR cat.categoryname LIKE :category_keyword) ");
		$sql->execute(array(':bookname_keyword'=>"%".$keywords."%",':course_keyword'=>"%".$keywords."%",':author_keyword'=>"%".$keywords."%",':bookkeywords_keyword'=>"%".$keywords."%",':category_keyword'=>"%".$keywords."%"));   
		$result = $sql->rowCount();
		if($result > 0){
			echo"<div class='content table-responsive table-full-width'>";
			echo "<table class='table table-hover table-striped'><thead><th>Category</th><th>Course</th><th>Book Name</th><th>Image</th><th>Author</th><th>Price</th><th>Stocks</th><th>Edit Book</th><th>Delete Book</th></thead>";
			while($row = $sql->fetch()){     
				echo "<tr><td>".$row["categoryname"]."</td><td>".$row["coursename"]." </td><td>".$row["bookname"]."</td>";
				echo "<td><img src='book_images/".$row['bookimage']."' height='100px'/></td>";
				echo "<td>".$row["author"]."</td><td>". $row['price']."</td><td>".$row["stock"]."</td> ";
				echo "<td><a href=\"editbook.php?bookid=$row[bookid]\" class='btn btn-primary hvr-grow' >Edit</a></td>";
				echo "<td><a href=\"deletebook.php?bookid=$row[bookid]\" class='btn btn-danger hvr-grow' onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";
			}
			echo "</table>";
			echo "</div>";
		} else {
			echo "<h3 style='text-align: center;'>No Book Details</h3>";
		}
	}catch(PDOException $e){
		die("ERROR: Could not able to execute $sql. " . $e->getMessage());
	}
}

if(isset($_POST['allusers'])){
	try{
		$sql = "SELECT * FROM tblusers";   
		$result = $pdo->query($sql);
		if($result->rowCount() > 0){
			echo"<div class='content table-responsive table-full-width'>";
			echo "<table class='table table-hover table-striped'><thead><th>Name</th><th>Phone</th><th>Address</th><th>Email</th><th>Delete Users</th></thead>";
			while($row = $result->fetch()){     
				echo "<tr><td>".$row["name"]."</td><td>".$row["phone"]." </td><td>".$row["address"]."</td>";
				echo "<td>".$row["email"]."</td>";
				echo "<td><a href=\"deleteuserdetails.php?userid=$row[userid]\" class='btn btn-danger hvr-grow' onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";
			}
			echo "</table>";
			echo "</div>";
		} else {
			echo "<h3 style='text-align: center;'>No Users</h3>";
		}
	} catch(PDOException $e){
		die("ERROR: Could not able to execute $sql. " . $e->getMessage());
	}
}

if(isset($_POST['searchusers'])){
	try{
		$keywords=$_POST['keywords'];
		$sql = $pdo->prepare("SELECT * FROM tblusers WHERE name LIKE :name_keyword ");
		$sql->execute(array(':name_keyword'=>"%".$keywords."%"));   
		$result = $sql->rowCount();
		if($result > 0){
			echo"<div class='content table-responsive table-full-width'>";
			echo "<table class='table table-hover table-striped'><thead><th>Name</th><th>Phone</th><th>Address</th><th>Email</th><th>Delete Users</th></thead>";
			while($row = $sql->fetch()){     
				echo "<tr><td>".$row["name"]."</td><td>".$row["phone"]." </td><td>".$row["address"]."</td>";
				echo "<td>".$row["email"]."</td>";
				echo "<td><a href=\"deleteuserdetails.php?userid=$row[userid]\" class='btn btn-danger hvr-grow' onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";
			}
			echo "</table>";
			echo "</div>";
		} else {
			echo "<h3 style='text-align: center;'>No Users</h3>";
		}
	}catch(PDOException $e){
		die("ERROR: Could not able to execute $sql. " . $e->getMessage());
	}
}

?>