<!doctype html>
<html lang="en">
<?php
    include('header.php');
?>
<body>

<div class="wrapper">
    <div class="sidebar" data-color="red" data-image="assets/img/sidebar-4.jpg">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

        <div class="sidebar-wrapper">
            <div class="logo">
                <a href="dashboard.php" class="simple-text">
                    E-Book_Rental | Admin
                </a>
            </div>

            <ul class="nav">
                <!-- <li >
                    <a href="dashboard.php">
                        <i class="pe-7s-graph"></i>
                        <p>Dashboard</p>
                    </a>
                </li> -->
                <li>
                    <a href="index.php">
                        <i class="pe-7s-user"></i>
                        <p>Users</p>
                    </a>
                </li>
                <li>
                    <a href="category_course.php">
                        <i class="pe-7s-note2"></i>
                        <p>Add Category & Course</p>
                    </a>
                </li>
                <li>
                    <a href="books.php">
                        <i class="pe-7s-notebook"></i>
                        <p>Add Books</p>
                    </a>
                </li>
                <li>
                    <a href="viewbooks.php">
                        <i class="pe-7s-display2"></i>
                        <p>View Books</p>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <div class="main-panel">
		<nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Manage Books</a>
                </div>
                <div class="collapse navbar-collapse">
                    <!-- <ul class="nav navbar-nav navbar-left">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="fa fa-dashboard"></i>
								<p class="hidden-lg hidden-md">Dashboard</p>
                            </a>
                        </li>
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="fa fa-globe"></i>
                                    <b class="caret hidden-sm hidden-xs"></b>
                                    <span class="notification hidden-sm hidden-xs">5</span>
									<p class="hidden-lg hidden-md">
										5 Notifications
										<b class="caret"></b>
									</p>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Notification 1</a></li>
                                <li><a href="#">Notification 2</a></li>
                                <li><a href="#">Notification 3</a></li>
                                <li><a href="#">Notification 4</a></li>
                                <li><a href="#">Another notification</a></li>
                              </ul>
                        </li>
                        <li>
                           <a href="">
                                <i class="fa fa-search"></i>
								<p class="hidden-lg hidden-md">Search</p>
                            </a>
                        </li>
                    </ul> -->

                    <ul class="nav navbar-nav navbar-right">
                        <!-- <li>
                           <a href="">
                               <p>Account</p>
                            </a>
                        </li> -->
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <p>
										Manage
										<b class="caret"></b>
									</p>

                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="viewbooks.php">Edit Books</a></li>
                                <li><a href="viewbooks.php">Delete Books</a></li>
                                
                                <!-- <li class="divider"></li>
                                <li><a href="#">Separated link</a></li> -->
                              </ul>
                        </li> 
                        <li>
                            <a href="logout.php">
                                <p>Log out</p>
                            </a>
                        </li>
						<li class="separator hidden-lg hidden-md"></li>
                    </ul>
                </div>
            </div>
        </nav>

        <?php
        error_reporting(0);
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "bookrent";
        try{
            $pdo = new PDO("mysql:host=$servername;dbname=$dbname", "$username","$password");
            // Set the PDO error mode to exception
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            //getting id from url
            $id = $_GET['bookid'];
     
            //selecting data associated with this particular id
            $sql = "SELECT c.courseid,c.coursename,cat.categoryid,cat.categoryname,b.bookid,b.category,b.course,b.bookname,b.bookimage,b.author,b.price,b.stock,b.book_keywords,b.bookdesc FROM tblbooks b,tblcategory cat, tblcourse c WHERE bookid=:id AND cat.categoryid=b.category AND c.courseid=b.course";
            $query = $pdo->prepare($sql);
            $query->execute(array(':id' => $id));
             
            while($row = $query->fetch(PDO::FETCH_ASSOC))
            {
                $bookname = $row['bookname'];
                $categoryid=$row['categoryid'];
                $category = $row['categoryname'];
                $courseid=$row['courseid'];
                $course = $row['coursename'];
                $author = $row['author'];
                $price = $row['price'];
                $stock = $row['stock'];
                $bookimage=$row['bookimage'];
                $bookdesc= $row["bookdesc"];
                $keywords= $row["book_keywords"];
            }

        }catch(PDOException $e){
            echo "ERROR: ".$e->getMessage();
        }
        $conn = null; 
    ?>

        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-10">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Edit Book</h4>
                            </div>
                            <div class="content">
                                <form action="updatebook.php" method="post" enctype="multipart/form-data">
                                    <input type="hidden" name="bookid" id="bookid" value=<?php echo $id;?> />
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Category name</label>
                                                <select class="form-control" id="txtCategory" name="txtCategory" required="">
                                                    <?php
                                                        $servername = "localhost";
                                                        $username = "root";
                                                        $password = "";
                                                        $dbname = "bookrent";

                                                        try{
                                                            $conn = new PDO("mysql:host=$servername;dbname=$dbname",$username,$password);
                                                            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                                                            $stmt = $conn->prepare("SELECT distinct(categoryid),categoryname FROM tblcategory GROUP BY categoryname");
                                                            $stmt->execute();
                                                            echo "<option value='$categoryid' selected>$category</option>";
                                                            while($res=$stmt->fetch(PDO::FETCH_ASSOC)){
                                                                if($categoryid != $res['categoryid']){
                                                                    $catid= $res['categoryid'];
                                                                    echo "<option value='$catid' >".$res['categoryname']."</option>";
                                                                }
                                                                
                                                            } 
                                                        }catch(PDOException $e){
                                                            echo "ERROR: ".$e->getMessage();
                                                        }

                                                        $conn = null; 
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                       <!--  <script type="text/javascript">
                                            function changecourse(val)
                                            {
                                                $.ajax({
                                                    type: 'post',
                                                    url: 'course.php',
                                                    data: {
                                                        get_option:val
                                                    },
                                                    success: function (response) {
                                                        document.getElementById("course").innerHTML=response; 
                                                    }
                                                });
                                            }
                                        </script> -->

                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Course name</label>
                                                
                                                <select class="form-control" id="course" name="txtCourse" required="">
                                                    <!-- Course.php -->
                                                <?php 
                                                    $servername = "localhost";
                                                    $username = "root";
                                                    $password = "";
                                                    $dbname = "bookrent";
                                                    
                                                    try{
                                                        $conn = new PDO("mysql:host=$servername;dbname=$dbname",$username,$password);
                                                        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                                                        $stmt = $conn->prepare("SELECT distinct(courseid),coursename FROM tblcourse");
                                                        $stmt->execute();
                                                        echo "<option value='$courseid' selected >$course</option>";
                                                        while($res=$stmt->fetch(PDO::FETCH_ASSOC)){
                                                            if($courseid != $res['courseid']){
                                                                $crsid=$res['courseid'];
                                                                echo "<option value='$crsid'>".$res['coursename']."</option>";
                                                            }
                                                        } 
                                                    }catch(PDOException $e){
                                                        echo "ERROR: ".$e->getMessage();
                                                    }
                                                    $conn = null;
                                                ?>
                                                </select> 
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Book name</label>
                                                <input type="text" class="form-control" placeholder="Book name" name="txtBook" required="" value="<?php echo "$bookname" ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="job">Book Description</label>
                                                <textarea name="txtbookdesc" id="txtbookdesc" class="form-control" rows="5" required="required" placeholder="Book Description" ><?php echo "$bookdesc" ?></textarea>
                                            </div> 
                                        </div> 
                                    </div>
                                        
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Author</label>
                                                <input type="text" class="form-control" placeholder="Author" name="txtAuthor" required="" value="<?php echo "$author" ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label>Price in Rs.</label>
                                                <input type="text" class="form-control" placeholder="Price in Rs." name="txtPrice" required="" value="<?php echo "$price" ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label>Stocks Available</label>
                                                <input type="text" class="form-control" placeholder="How many books" name="txtStock" required="" value="<?php echo "$stock" ?>">
                                            </div>
                                        </div>  
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Keywords</label>
                                                <input type="text" class="form-control" placeholder="Author" name="txtkeywords" required="" value="<?php echo "$keywords" ?>">
                                            </div>
                                        </div>                               
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div > 
                                                <input type="submit" name="submit" class="btn btn-info btn-fill hvr-grow" style="margin-top: 1px;" value="UPDATE"/>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <!--  -->
                    </div>

                </div>
            </div>
        </div>

        <footer class="footer">
            <div class="container-fluid">
                <?php
                    include('footer.php');
                ?>
            </div>
        </footer>

    </div>
</div>
</body>

    <!--   Core JS Files   -->
    <script type="text/javascript">
        window.setTimeout(function () {
            $(".alert-success").fadeTo(500, 0).slideUp(500, function () {
                $(this).remove();
            });
        }, 1000);

    </script>
    <script src="assets/js/jquery.3.2.1.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>
    
</html>
