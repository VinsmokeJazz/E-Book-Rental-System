
<?php
session_start();
	// echo "customer is ".$_SESSION["cid"];
if ($_SESSION["cid"] == NULL){
	header('location: register.php');
}
$userID = $_SESSION["cid"];
		// Database connection part
require("dbhelper.php");
?>

<?php
//Code to display all the categories in side navigation
// if(isset($_POST["category"])){
// 	try{
// 		// $category_query = "SELECT c.courseid,c.coursename,c.category,cat.categoryid,cat.categoryname FROM tblcategory cat,tblcourse c where cat.categoryid=c.category";
// 		$category_query = "SELECT * FROM tblcategory GROUP BY(categoryname)";
// 		$result = $pdo->query($category_query);

// 		echo "<div class='nav nav-pills nav-stacked' style='border: 1px solid #428bca;''><li class='active'><a><h4>Categories</h4></a></li>";

// 		if($result->rowCount() > 0){                                       
// 			while($row = $result->fetch()){ 
// 				$catid= $row["categoryid"];
// 				$catname = $row['categoryname'];
// 				echo "<div class='container'>";
// 					echo "<br><div class='dropdown' id='bg'>";
// 						echo "<br><a href='#' catid='$catid' >$catname</a>";

// 						$course_query="SELECT courseid,coursename,category FROM tblcourse  where category= ".$catid;
// 						$result1 = $pdo->query($course_query);
// 						if($result1->rowCount() > 0){        
// 							echo "<li class='dropdown-content'>";                             
// 								while($row1 = $result1->fetch()){ 
// 									$courseid=$row1['courseid'];
// 									$course=$row1['coursename'];		
// 									echo "

// 				                        	<a href='#' class='course'  cid='$courseid' > $course</a>

// 				                    ";
// 				                }
// 				            echo "</li>";
// 			            }
// 					echo "</div>";
// 				echo "</div>";
// 			} 
// 			echo "</div>";    
// 		}else{
// 			echo "<h5>No categories</h5>";
// 		}
// 	} catch(PDOException $e){
// 		die("ERROR: Could not able to execute $sql. " . $e->getMessage());
// 	}
// }

//--------------------Code to display category and course in the side navigation used in customerbooks.php and category.php--------------------------
if(isset($_POST["category"])){
	try{
		// $category_query = "SELECT c.courseid,c.coursename,c.category,cat.categoryid,cat.categoryname FROM tblcategory cat,tblcourse c where cat.categoryid=c.category";
		$category_query = "SELECT * FROM tblcategory GROUP BY(categoryname)";
		$result = $pdo->query($category_query);

		echo "<div class='nav nav-pills nav-stacked' style='border: 1px solid #428bca;''><li class='active'><a><h4>Categories</h4></a></li>";

		if($result->rowCount() > 0){                                       
			while($row = $result->fetch()){ 
				$catid= $row["categoryid"];
				$catname = $row['categoryname'];
				
				echo "<li class='container'>";
				echo "<h5>$catname</h5>";

				$course_query="SELECT courseid,coursename,category FROM tblcourse  where category= ".$catid;
				$result1 = $pdo->query($course_query);
				
				if($result1->rowCount() > 0){        
					
					echo "<ul class='fa-ul'>";                             
					while($row1 = $result1->fetch()){ 
						$courseid=$row1['courseid'];
						$course=$row1['coursename'];	
						echo "<li><i class='fa-li fa fa-check'></i><a href='#' class='course'  cid='$courseid' > $course</a></li>";
					}
					echo "</ul>";
				}

				echo "</li>";
			} 
			echo "</div>";    
		}else{
			echo "<h5>No categories/course</h5>";
		}
	} catch(PDOException $e){
		die("ERROR: Could not able to execute $sql. " . $e->getMessage());
	}
}

//--------------------Code to display all the books used in customerbooks.php and category.php--------------------------
if(isset($_POST["book"])){
	try{
		// $limit=3;
		// if(isset($_POST["setpage"])){
		// 	$pageno=$_POST["pagenumber"];
		// 	$start=($pageno * $limit) - $limit;
		// }else{
		// 	$start=0;
		// }

		$book_query = $pdo->prepare("SELECT b.bookid,b.category,b.course,b.bookname,b.bookimage,b.author,b.price,b.stock,c.courseid,c.coursename,cat.categoryid,cat.categoryname FROM tblbooks b,tblcategory cat,tblcourse c WHERE b.category=cat.categoryid AND b.course=c.courseid 	");
		//ORDER BY RAND() LIMIT 0,6  LIMIT ?,?
		// $book_query->execute([$start,$limit]);
		// $book_query->bindParam(1, $start,PDO::PARAM_INT);
		// $book_query->bindParam(2, $limit,PDO::PARAM_INT);
		$book_query->execute();

		if($book_query->rowCount() > 0){

			while($row = $book_query->fetch()){ 
				$check=false;
				$bookid=$row['bookid'];

				echo "<div class='col-md-4 col-sm-12 col-xs-12'>";
				echo "<div class='panel panel-primary' align='center'>";
				echo "<div class='panel-heading'>";
				echo "<a href='' bid='$bookid' class='bookdetails'><img src='admin/book_images/".$row['bookimage']."' style='height: 200px;width:150px;padding-top: 10px;' alt='' class='img-responsive'></a>";
				echo "</div>";
				echo "<div class='panel-body' align='center'>";
				echo "<h5 style='text-align:center;'>".$row['coursename']."</h5>";
				echo "<h5 style='text-align:center;'>".$row['bookname']."</h5>";
				echo "<h5 style='text-align:center;'>Rs.".$row['price']."</h5>";
				echo "</div>";
				echo "<div class='panel-footer'>";

				// $sql1 = $pdo->prepare("SELECT * FROM tblstore WHERE userid=:userid AND bookid=:bookid");
				// $sql1->execute(["userid"=>$userID,"bookid"=>$bookid]);
				// $count=$sql1->rowCount();
				// if($count > 0){
				// 	$check=true;
				// }   
				// if($check == false){
				// 	echo "<button bookid='".$row['bookid']."' id='bookwishlist' type='button'  class='btn btn-danger inline bukval-$bookid'><span class='fa fa-heart'></span></button> &nbsp;&nbsp;&nbsp;";
				// }
				echo "<button bookid='".$row['bookid']."' id='bookwishlist' type='button'  class='btn btn-danger inline bukval-$bookid'><span class='fa fa-heart'></span></button> &nbsp;&nbsp;&nbsp;";
				if($row['stock'] > 0){
					echo "<button bookid='".$row['bookid']."' id='book' type='button'  class='btn btn-danger inline bookval-$bookid'>Add To Cart</button>";
				}else{
					echo "<button class='btn btn-danger inline disabled'>Unavailable</button>";
				}
				echo "</div>";
				echo "</div>";
				echo "</div>";
			}
		} else {
			echo "<h3 style='text-align: center;'>No Book Details</h3>";
		}
	} catch(PDOException $e){
		die("ERROR: Could not able to execute. " . $e->getMessage());
	}
}  

// ----------------Code to display the book details on clicking of an image used in customerbooks.php and category.php-----------------------
if(isset($_POST['getbookdetails'])){
	$bookid=$_POST['b_id'];
	$sql=$pdo->prepare("SELECT b.bookid,b.bookname,b.author,b.category,b.course,b.bookdesc,b.price,b.stock,b.bookimage,b.book_keywords,cat.categoryname,cat.categoryid,c.courseid,c.coursename from tblbooks b,tblcategory cat,tblcourse c where cat.categoryid=b.category AND c.courseid=b.course AND bookid=".$bookid);
	$sql->execute();
	if($sql->rowCount() > 0){
		while($row = $sql->fetch()){
			$bid=$row['bookid'];
			$cat=$row['course'];                                   
			echo "<div class='row' id='productMain'>
			<div class='col-sm-12 col-xs-12 col-md-5'>
				<div id='mainImage'>
					<img src=admin/book_images/". $row['bookimage'] ." alt='book' style='height: 400px;width:380px;'' class='img-responsive'>
				</div>
			</div>
			<div class='col-sm-12 col-xs-12 col-md-6'>
				<div class='box'>
					<h2 class='text-center'>".$row['bookname']."</h2>
					<label><b>Author      : </b>".$row['author']."</label> <br>
					<label><b>Availability: </b>".$row['stock']."</label> <br>
					<label><b>Description : </b>".$row['bookdesc']."</label>
					<p class='price'>₹".$row['price']."</p>
					<p class='text-center buttons'>";
						if($row['stock'] < 0){
							echo "<button class='btn btn-danger inline disabled'>Unavailable</button>&nbsp;&nbsp;&nbsp;";
						}else{
							echo "<button class='btn btn-primary bookval-$bid' bookid=".$row['bookid']." id='book'><i class='fa fa-shopping-cart'></i> Add to Cart</button> ";
						}
						echo "<button bookid='".$row['bookid']."' id='bookwishlist' type='button'  class='btn btn-danger inline bukval-$bookid'><span class='fa fa-heart'></span></button>
					</p>
				</div>
				<div class='pull-right'>
					<a href='customerbooks.php' class='btn btn-primary'><i class='fa fa-chevron-left'></i> Back</a>
				</div>

			</div>
		</div>";
	}
}
}

//------Code for getting books by selecting particular course and also code for search using keywords used in customerbooks.php and category.php------------ 
if(isset($_POST["getSelectedCourse"]) || isset($_POST["search"]) ) {
	try{
		if(isset($_POST["getSelectedCourse"])) {
			// $limit=3;
			// if(isset($_POST["setpage"])){
			// 	$pageno=$_POST["pagenumber"];
			// 	$start=($pageno * $limit) - $limit;
			// }else{
			// 	$start=0;
			// }

			$crsid = $_POST["course_id"];
			$crsselectedquery = $pdo->prepare("SELECT b.bookid,b.course,b.bookname,b.bookimage,b.author,b.price,b.stock,c.courseid,c.coursename FROM tblbooks b,tblcourse c WHERE b.course=:crsid AND b.course=c.courseid ");
			// $crsselectedquery->bindParam(1, $crsid,PDO::PARAM_INT);
			// $crsselectedquery->bindParam(2, $start,PDO::PARAM_INT);
			// $crsselectedquery->bindParam(3, $limit,PDO::PARAM_INT);
			// $crsselectedquery->execute();
			$crsselectedquery->execute(["crsid"=>$crsid]);

		}else if(isset($_POST["search"])){
			$keywords = $_POST["keywords"];
			$crsselectedquery = $pdo->prepare("SELECT b.bookid,b.course,b.bookname,b.bookimage,b.author,b.price,b.stock,b.book_keywords,c.courseid,c.coursename FROM tblbooks b,tblcourse c WHERE b.course=c.courseid AND b.book_keywords LIKE :keywords ");
			$crsselectedquery->execute(array(':keywords' => "%".$keywords."%"));
		}	

		if($crsselectedquery->rowCount() > 0){      
			while($row = $crsselectedquery->fetch()){ 
				$bookid=$row['bookid'];
				echo "<div class='col-md-4 col-sm-12 col-xs-12'>";
				echo "<div class='panel panel-primary' align='center'>";

				echo "<div class='panel-heading'>";
				echo "<a class='bookdetails' bid='$bookid'><img src='admin/book_images/".$row['bookimage']."' style='height: 200px;width:150px;padding-top: 10px;' alt='' class='img-responsive'></a>";
				echo "</div>";
				echo "<div class='panel-body' align='center'>";
				echo "<h5 style='text-align:center;'>".$row['coursename']."</h5>";
				echo "<h5 style='text-align:center;'>".$row['bookname']."</h5>";
				echo "<h5 style='text-align:center;'>Rs.".$row['price']."</h5>";
				echo "</div>";
				echo "<div class='panel-footer'>";
				echo "<button bookid='".$row['bookid']."' id='bookwishlist' type='button'  class='btn btn-danger inline bukval-$bookid'><span class='fa fa-heart'></span></button> &nbsp;&nbsp;&nbsp;";
				if($row['stock'] > 0){
					echo "<button bookid='".$row['bookid']."' id='book' type='button' class='btn btn-danger inline bookval-$bookid'>Add To Cart</button>";
				}else{
					echo "<button class='btn btn-danger inline disabled'>Unavailable</button>";
				}
				echo "</div>";
				echo "</div>";
				echo "</div>";
			}

		} else {
			echo "<h3 style='text-align: center;'>No Book Details</h3> ";
		}
	} catch(PDOException $e){
		die("ERROR: Could not able to execute  " . $e->getMessage());
	}
}

//------------------------Adding to store code used in customerbooks.php--------------------------------
if(isset($_POST['addToStore'])){
	$bookid = $_POST['bookid'];

	$sql = $pdo->prepare("SELECT * FROM tblstore WHERE userid=:userid AND bookid=:bookid");
	$sql->execute(["userid"=>$userID,"bookid"=>$bookid]);
	$count=$sql->rowCount();
	if($count > 0){
		print 0;
	}else{
		$sql=$pdo->prepare("SELECT * FROM tblbooks WHERE bookid=:bookid");
		$sql->execute(["bookid"=>$bookid]);
		$row=$sql->fetch();
		$bookid=$row['bookid'];
		$price=$row['price'];
		$sql=$pdo->prepare("INSERT INTO tblstore(storeid,userid,bookid,qty,totalamount)VALUES(NULL,:userid,:bookid,:qty,:total)");
		$sql->bindParam(':userid',$userID);
		$sql->bindParam(':bookid',$bookid);
		$sql->bindValue(':qty',1);
		$sql->bindParam(':total',$price);
		$result=$sql->execute();
		if($result > 0){
			print 1;
		}
	}
}

//------------------------Adding to wishlist code used in customerbooks.php--------------------------------
if(isset($_POST['addToWishlist'])){
	$bookid = $_POST['bookid'];
	$sql = $pdo->prepare("SELECT * FROM tblwishlist WHERE userid=:userid AND bookid=:bookid");
	$sql->execute(["userid"=>$userID,"bookid"=>$bookid]);
	$count=$sql->rowCount();
	if($count > 0){
		print 0;
	}else{
		$sql=$pdo->prepare("SELECT * FROM tblbooks WHERE bookid=:bookid");
		$sql->execute(["bookid"=>$bookid]);
		$row=$sql->fetch();
		$bookid=$row['bookid'];
		$price=$row['price'];
		$qty=$row['stock'];
		$prvstatus = 1 ;
		if($qty > 0){
			$status = 1;
		}else{
			$status = 0;
		}

		$sql=$pdo->prepare("INSERT INTO tblwishlist(wishlistid,userid,bookid,prvstatus,status)VALUES(NULL,:userid,:bookid,:pstatus,:status)");
		$sql->bindParam(':userid',$userID);
		$sql->bindParam(':bookid',$bookid);
		$sql->bindParam(':pstatus',$prvstatus);
		$sql->bindParam(':status',$status);

		$result=$sql->execute();
		if($result > 0){
			print 1;
		}
		$sql = $pdo->prepare("SELECT * FROM tblwishlist WHERE userid=:userid AND bookid=:bookid");
		$sql->execute(["userid"=>$userID,"bookid"=>$bookid]);
		while($row=$sql->fetch()){
			$bookid=$row['bookid'];
		}
	}	
}

//------------------------Adding to store/cart from wishlist page code in wishlist.php--------------------------------
if(isset($_POST['addToCartFromWL'])){
	$bookid = $_POST['bookid'];

	$sql = $pdo->prepare("SELECT * FROM tblstore WHERE userid=:userid AND bookid=:bookid");
	$sql->execute(["userid"=>$userID,"bookid"=>$bookid]);
	$count=$sql->rowCount();
	if($count > 0){
		print 0;
	}else{
		$sql=$pdo->prepare("SELECT * FROM tblbooks WHERE bookid=:bookid");
		$sql->execute(["bookid"=>$bookid]);
		$row=$sql->fetch();
		$bookid=$row['bookid'];
		$price=$row['price'];
		$sql=$pdo->prepare("INSERT INTO tblstore(storeid,userid,bookid,qty,totalamount)VALUES(NULL,:userid,:bookid,:qty,:total)");
		$sql->bindParam(':userid',$userID);
		$sql->bindParam(':bookid',$bookid);
		$sql->bindValue(':qty',1);
		$sql->bindParam(':total',$price);
		$result=$sql->execute();
		if($result > 0){
			print 1;
		}
		$sql=$pdo->prepare("DELETE FROM tblwishlist WHERE userid=:userid AND bookid=:bookid");
		$sql->bindParam(":userid",$userID);
		$sql->bindParam(":bookid",$bookid);
		$result=$sql->execute();
	}
}


//to count availability of out of stock books
if(isset($_POST["wishlist_avail"])){

	$sql = $pdo->prepare("SELECT * from tblwishlist where userid=:userid");
	$sql->execute(["userid"=>$userID]);
	$count = 0;

	if($sql->rowCount() > 0){
		while ($row=$sql->fetch()) {
			$prevstatus = $row['prvstatus'];
			$bookid = $row['bookid'];
			$cstatus = $row['status'];
			$nstatus = $row['not_status'];
			if((($prevstatus == 0 && $cstatus == 1 && $nstatus == 0) || ($prevstatus == 0 && $cstatus == 1 && $nstatus == 1)) && (!($prevstatus == 0 && $cstatus == 1 && $nstatus == 1) || ($prevstatus == 1 && $cstatus == 1 && $nstatus == 0)))
			{
				$count = $count + 1;
			}
		}
		$sql=$pdo->prepare("UPDATE tblwishlist SET not_status=1 WHERE not_status=0 AND prvstatus = 0");	
		$sql->execute();
		print $count;
	}
}

// --------------- To delete the book from the wishlist used in wishlist.php----------------------
if(isset($_POST['deletefromswishlist'])){
	$bookdelid=$_POST['delete_id']; 
	$sql=$pdo->prepare("DELETE FROM tblwishlist WHERE userid=:userid AND bookid=:bookid");
	$sql->bindParam(":userid",$userID);
	$sql->bindParam(":bookid",$bookdelid);
	$result=$sql->execute();
	if($result > 0){
		/* echo "Deleted"; */
		/* header("location : wishlist.php"); */
	}
}

//------------------------------------Cart container in header used in customerbooks.php----------------------------
if(isset($_POST['get_cart_books']) || isset($_POST['getstorecheckout'])) {
	$sql = $pdo->prepare("SELECT s.bookid,b.bookid,b.bookimage,b.bookname,b.price,b.stock,s.qty,s.totalamount FROM tblstore s,tblbooks b WHERE s.bookid=b.bookid AND userid = :userid");
	$sql->execute(["userid"=>$userID]);
	if($sql->rowCount() > 0){
		$no=1;
		$GrandTotal=0;
		$TotalQty=0;
		while ($row=$sql->fetch()) {
			$bookid=$row['bookid'];
			$name=$row['bookname'];
			$image=$row['bookimage'];
			$price=$row['price'];
			$qty=$row['qty'];
			$stock=$row['stock'];
			$totalamount=$row['totalamount'];
			$AmountArray = array($totalamount);
			$AmountSum=array_sum($AmountArray);
			$GrandTotal=$GrandTotal + $AmountSum;

			$TotalQty=$TotalQty+$qty;

			if(isset($_POST['get_cart_books'])){
				echo "<div class='row' style='margin-top:4px;margin-bottom:4px'>
				<div class='col-md-3 col-sm-3 col-xs-3'>$no</div>
				<div class='col-md-3 col-sm-3 col-xs-3'><img src='admin/book_images/$image' style='height: 80px;width:100px;' alt='' class='img-responsive'>
				</div>
				<div class='col-md-3 col-sm-3 col-xs-3'>$name</div>
				<div class='col-md-3 col-sm-3 col-xs-3'>$price</div>
			</div>
			";
			$no = $no +1;
		}else {
			echo "<br>
			<tr>
				<td style='width:140px;'>$name</td>
				<td ><img src='admin/book_images/$image' style='height: 80px;width:80px;' alt='book' class='img-responsive'></td>
				<td ><input type='text' disabled class='form-control price' bid='$bookid' id='price-$bookid' value='$price' style='width:60px;'/></td>
				<td ><input type='number' class='form-control qty' bid='$bookid' id='qty-$bookid' value='$qty' style='width:60px;'/></td>
				<td ><input type='text' disabled class='form-control total' bid='$bookid' id='total-$bookid' value='$totalamount' style='width:80px;'/></td>
				<input type='hidden' class='form-control stock' bid='$bookid' id='stock-$bookid' value='$stock'/>
				<td>
					
					<a href='#' deleteid='$bookid' class='btn btn-danger delete'>Delete <span class='fa fa-trash-o fa-lg' ></span></a>
				</td>
			</tr>
			";
			echo "<tr><td id='moreqty-$bookid' style='display:none;color:red;border:none;' colspan='5'></td></tr>";
		}
	}
	echo "<input type='hidden' class='form-control sumqty'  id='sum' value='$TotalQty'/>";
	$sql2=$pdo->prepare("SELECT SUM(qty) AS sumqty from tblstore where userid=:userid");
	$sql2->execute(["userid"=>$userID]);
	$row = $sql2->fetch(PDO::FETCH_ASSOC);
	if($row['sumqty']>=16){
		echo "<tr><td colspan='5'><p style=color:red;>OOPS!!! Total number of books should not be more than 15.</p></td></tr>";
	} 
	if(isset($_POST['getstorecheckout'])) {
		echo "<tfoot>
		<tr>
			<th colspan='4'>Grand Total</th>
			<th colspan='3'>Rs. $GrandTotal</th>
		</tr>
	</tfoot>";
}

if(isset($_POST['get_cart_books'])){
	echo "<div class='panel-footer'>";
	$sql=$pdo->prepare("SELECT * FROM tblstore WHERE userid=:userid");
	$sql->bindParam(":userid",$userID);
	$sql->execute();
	if($sql->rowCount() > 0){
		echo "<a href='store.php' class='btn btn-danger' style='margin-left: 190px;'>View Cart <span class='fa fa-shopping-cart'></span></a>";
	}
	echo "</div>";
}
}else{
	echo "<script>
	$('.checkqty').attr('disabled','disabled');
	";
}
}

// -------------------Count of books added to store displayed in header as a badge used in customerbooks.php---------------------------
if(isset($_POST["cart_count"])){
	$sql = $pdo->prepare("SELECT * FROM tblstore WHERE userid = :userid");
	$sql->execute(["userid"=>$userID]);
	echo $sql->rowCount();
}

// -------------------Count of  books added to wishlist displayed in header as a badge (wishlistbadge) used in customerbooks.php---------------------------
if(isset($_POST["wishlist_count"])){
	$sql = $pdo->prepare("SELECT * FROM tblwishlist WHERE userid = :userid");
	$sql->execute(["userid"=>$userID]);
	echo $sql->rowCount();
}

//-----------------No. of rows in a page used in customerbooks.php to get pagination------------------------------
if(isset($_POST["page"])){
	// $sql=$pdo->prepare("SELECT b.bookid,b.category,b.course,b.bookname,b.bookimage,b.author,b.price,b.stock,c.courseid,c.coursename,cat.categoryid,cat.categoryname FROM tblbooks b,tblcategory cat,tblcourse c WHERE b.category=cat.categoryid AND b.course=c.courseid");
	// $sql->execute();
	$sql="SELECT * FROM tblbooks";
	$result=$pdo->query($sql);
	$count = $result->rowCount();

	// $row=$result->fetch();
	// $course_id=$row['course'];
	
	$pageno = ceil($count/3);
	for ($i=1; $i<=$pageno ; $i++){
		echo "
		<li><a href='#' page='$i' id='page' course_id='$course_id'>$i</a></li>
		";
	}
}

// --------------- To delete the book from the store used in store.php----------------------
if(isset($_POST['deletefromstore'])){
	$bookdelid=$_POST['deleteid'];
	$sql=$pdo->prepare("DELETE FROM tblstore WHERE userid=:userid AND bookid=:bookid");
	$sql->bindParam(":userid",$userID);
	$sql->bindParam(":bookid",$bookdelid);
	$result=$sql->execute();
	if($result > 0){
		echo "Deleted";
	}

	$sql=$pdo->prepare("DELETE FROM tblorderbook WHERE userid=:userid AND bookid=:bookid");
	$sql->bindParam(":userid",$userID);
	$sql->bindParam(":bookid",$bookdelid);
	$result=$sql->execute();

	$sql=$pdo->prepare("DELETE FROM tblwishlist WHERE userid=:userid AND bookid=:bookid");
	$sql->bindParam(":userid",$userID);
	$sql->bindParam(":bookid",$bookdelid);
	$result=$sql->execute();
}

// --------------- To update the book from the store used in store.php----------------------
if(isset($_POST['updatefromstore'])){
	$bookupdateid=$_POST['updateid'];
	$qty=$_POST['qty'];
	$price=$_POST['price'];
	$totalamount=$_POST['total'];

	$sql = $pdo->prepare("SELECT stock FROM tblbooks WHERE bookid = :bookid");
	$sql->execute(["bookid"=>$bookupdateid]);
	$row=$sql->fetch();
	$stock=$row['stock'];

	if($qty > $stock){
		print 1;
	}else{
		$sql=$pdo->prepare("UPDATE tblstore SET qty=:qty, totalamount=:totalamount WHERE userid=:userid AND bookid=:bookid");
		$sql->bindParam(":qty",$qty);
		$sql->bindParam(":totalamount",$totalamount);
		$sql->bindParam(":userid",$userID);
		$sql->bindParam(":bookid",$bookupdateid);
		$result=$sql->execute();
		// echo "Updated";
	}

	$sql=$pdo->prepare("UPDATE tblorderbook SET qty=:qty, totalamount=:totalamount WHERE userid=:userid AND bookid=:bookid");
	$sql->bindParam(":qty",$qty);
	$sql->bindParam(":totalamount",$totalamount);
	$sql->bindParam(":userid",$userID);
	$sql->bindParam(":bookid",$bookupdateid);
	$result=$sql->execute();
}

// --------------To display the number of books in the store in the box header as a paragraph used in store.php----------------------------
if(isset($_POST['getNumOfRecords'])){
	$sql=$pdo->prepare("SELECT * FROM  tblstore where userid=:userid");
	$sql->execute([':userid'=>$userID]);
	$result=$sql->rowCount();
	if($result>1){
		echo "You currently have " . $result . " item(s) in your cart." ;
	}else {
		echo "You currently have " . $result . " item in your cart." ;
	}
}

// --------------To restrict fom qty more than 15 in store.php----------------------------
if(isset($_POST['sumqtyfn'])){
	$qty=$_POST['sumqty'];
	echo $qty;
}

// -------------- To update the total and gradtotal to the database on changing of QUANTITY---------
if(isset($_POST['updatestore'])){
	$bookupdateid=$_POST['updateid'];
	$qty=$_POST['qty'];
	$totalamount=$_POST['total'];

	$sql = $pdo->prepare("SELECT stock FROM tblbooks WHERE bookid = :bookid");
	$sql->execute(["bookid"=>$bookupdateid]);
	$row=$sql->fetch();
	$stock=$row['stock'];

	if($qty > $stock){
		print 1;
	}else{
		$sql=$pdo->prepare("UPDATE tblstore SET qty=:qty, totalamount=:totalamount WHERE userid=:userid AND bookid=:bookid");
		$sql->bindParam(":qty",$qty);
		$sql->bindParam(":totalamount",$totalamount);
		$sql->bindParam(":userid",$userID);
		$sql->bindParam(":bookid",$bookupdateid);
		$result=$sql->execute();
		//echo "Updated";
	}
	$sql=$pdo->prepare("UPDATE tblorderbook SET qty=:qty, totalamount=:totalamount WHERE userid=:userid AND bookid=:bookid");
	$sql->bindParam(":qty",$qty);
	$sql->bindParam(":totalamount",$totalamount);
	$sql->bindParam(":userid",$userID);
	$sql->bindParam(":bookid",$bookupdateid);
	$result=$sql->execute();
}

//------------------------- My Account Details ------------------------
if(isset($_POST['getuserdetails'])){
	$sql=$pdo->prepare("SELECT * from tblusers where userid=:userid");
	
	$sql->execute(["userid"=>$userID]);
	if($sql->rowCount() > 0){

		while ($row=$sql->fetch()) {
			$name=$row['name'];
			$phone=$row['phone'];
			$addr=$row['address'];
			$mail=$row['email'];
			$uname=$row['username'];
			$pass=$row['password'];
		}
	}

	echo "<div class='row'>
	<div class='col-md-6 col-sm-12 col-xs-12'>
		<div class='form-group'>
			<label for='name'> Name [ Includes .(dot) spaces and _ ]</label>
			<input type='text' class='form-control' id='name' name='txtUname' value='$name' required>
		</div>
	</div>                            
	<div class='col-md-6 col-sm-12 col-xs-12'>
		<div class='form-group'>
			<label for='password'>Phone Number [ 10 digits ]</label>
			<input type='text' class='form-control' id='num' name='txtPassword' value='$phone' required>
		</div>
	</div>
</div>
<div class='row'>
	<div class='col-md-12 col-sm-12 col-xs-12'>
		<div class='form-group'>
			<label for='name'>Address</label>
			<textarea name='txtAddress' id='addr' class='form-control' rows='5' cols='5'  style='height:100px;' required>$addr</textarea>
		</div>
	</div>
</div>
<div class='row'>
	<div class='col-md-12 col-sm-12 col-xs-12'>
		<div class='form-group'>
			<label for='email'>Email</label>
			<input type='email' class='form-control' id='mail' name='txtEmail' value='$mail' required>
		</div>
	</div>
</div>
<div class='row'>
	<div class='col-md-6 col-sm-12 col-xs-12'>
		<div class='form-group'>
			<label for='name'>User Name</label>
			<input type='text' class='form-control' id='usern' name='txtUname' value='$uname' required>
		</div>
	</div>                            
	<div class='col-md-6 col-sm-12 col-xs-12'>
		<div class='form-group'>
			<label for='password'>Password</label>
			<input type='password' class='form-control' id='pass' name='txtPassword' value='$pass' required>
		</div>
	</div>
</div> ";
}

//--------------------- Update with edited user details ---------------------------
if(isset($_POST['editacc'])){
	$data=0;
	$name=$_POST["name"];
	$phone=$_POST["num"];
	$addr=$_POST["addr"];
	$mail=$_POST["mail"];
	$uname=$_POST["usern"];
	$pass=$_POST["pass"];
	$len=strlen($pass);
	if(( !empty($name)) && (!empty($phone)) && (!empty($addr))  && (!empty($mail))  && (!empty($uname)) && ($len >= 8) && (preg_match("/^[a-zA-Z\. ]+$/",$name)) && ((preg_match("/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/",$mail)))) {
		$sql=$pdo->prepare("UPDATE tblusers SET name=:name, phone=:phone, address=:addr, email=:mail, username=:uname, password=:pass WHERE userid=:userid");
		$sql->bindParam(":name",$name);
		$sql->bindParam(":phone",$phone);
		$sql->bindParam(":addr",$addr);
		$sql->bindParam(":mail",$mail);
		$sql->bindParam(":uname",$uname);
		$sql->bindParam(":pass",$pass);
		$sql->bindParam(":userid",$userID);
		$result=$sql->execute(); 
			print 1;
	}else{
			print 0;
	} 
}
?>
