
<!-- *** COPYRIGHT ***
   _________________________________________________________ -->
   <div id="copyright">
      <div class="container">
         <div class="col-md-6">
            <p class="pull-left">      
               &copy; <script>document.write(new Date().getFullYear())</script> | E-BookRental, Online Book Store
            </p>
         </div>
         <!-- <div class="col-md-6">
            <p class="pull-right">
               &copy; <script>document.write(new Date().getFullYear())</script> | E-BookRental, Online Book Store
            </p>
         </div> -->
      </div>
   </div>
   <!-- *** COPYRIGHT END *** -->