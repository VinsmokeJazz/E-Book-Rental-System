<!DOCTYPE html>
<html lang="en">
<head>
    <?php
    include('header.php');
    ?>
    <style>
        body {font-family: Arial, Helvetica, sans-serif;}

        input[type=text], input[type=password], input[type=email] {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        /* The Modal (background) */
        .modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1; /* Sit on top */
            padding-top: 100px; /* Location of the box */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgb(0,0,0); /* Fallback color */
            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
        }

        /* Modal Content */
        .modal-content {
            position: relative;
            background-color: #fefefe;
            margin: auto;
            padding: 0;
            border: 1px solid #888;
            width: 50%;
            /*height: 60%;*/
            box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
            -webkit-animation-name: animatetop;
            -webkit-animation-duration: 0.4s;
            animation-name: animatetop;
            animation-duration: 0.4s
        }           
        /* Add Animation */
        @-webkit-keyframes animatetop {
            from {top:-300px; opacity:0} 
            to {top:0; opacity:1}
        }

        @keyframes animatetop {
            from {top:-300px; opacity:0}
            to {top:0; opacity:1}
        }

        /* The Close Button */
        .close {
            color: white;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: #000;
            text-decoration: none;
            cursor: pointer;
        }

        .modal-header {
            padding: 2px 10px;
            background-color: #428bca;
            color: white;
        }

        .modal-body {padding: 2px 10px;}

        .modal-footer {
            padding: 2px 16px;
            background-color: #428bca;
            color: white;
        }
    </style>
</head>
<body>
    <div id="all">
            <!-- *** NAVBAR ***
            _________________________________________________________ -->

            <div class="navbar navbar-default yamm navbar-fixed-top" role="navigation" id="navbar">
                <div class="container">
                    <div class="navbar-header">
                       <a href="index.php" >
                        <img src="img/logo.png" alt="E-BookRental" data-animate-hover="shake"> 
                        </a>
                        <div class="navbar-buttons">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation">
                                <span class="sr-only">Toggle navigation</span>
                                <i class="fa fa-align-justify"></i>
                            </button>
                        </div>
                    </div>
                <!--/.navbar-header -->

                    <div class="navbar-collapse collapse right" id="navigation">
                        <ul class="nav navbar-nav navbar-right">
                            <li><a id="bg" href="index.php">Home</a></li> 
                            <li class="active"><a>Register/Login</a></li> 
                            <li><a id="bg" href="category.php">Category</a></li> 
                        </ul> 
                    </div>
                <!--/.nav-collapse -->
            </div>
            <!-- /.container -->
        </div>
        <!-- /#navbar -->

        <!-- *** NAVBAR END *** -->

        <div id="content" style="margin-top: 70px">
            <div class="container">

                <div class="col-md-12 col-sm-12 col-xs-12">

                    <ul class="breadcrumb">
                        <li><a href="index.php">Home</a>
                        </li>
                        <li>New account / Sign in</li>
                    </ul>

                </div>

                <div class="col-md-6 col-sm-12 col-xs-12">
                    <div class="box">
                        <?php
                        if(isset($_POST['submit'])){
                            $name = $addr = $email = $phone = $psw = "";
                            $name = $_POST["txtName"];
                            $addr = $_POST["txtAddress"];
                            $phone = $_POST["txtPhone"];
                            $psw = $_POST["txtPassword"];
                            $email = $_POST["txtEmail"];  
                            $uname = $_POST["txtUname"];

                            $custcheck = false;

                            $servername = "localhost";
                            $username = "root";
                            $password = "";
                            $dbname = "bookrent";

                            try{
                                $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                                    // set the PDO error mode to exception
                                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                                $stmt = $conn->prepare("SELECT * FROM tblusers WHERE username = :username");
                                $stmt->bindParam(':username',$uname);
                                $stmt->execute();

                                $res = $stmt->fetch(PDO::FETCH_ASSOC);

                                if($res){
                                    $custcheck = true;
                                }

                                if($custcheck == false){
                                    $stmt = $conn->prepare("INSERT INTO tblusers(userid,name,phone,address,email,username,password) VALUES (NULL, :name,:phone,:addr,:email,:username,:psw)");

                                    $stmt->bindParam(':name',$name);
                                    $stmt->bindParam(':phone',$phone);
                                    $stmt->bindParam(':addr',$addr);
                                    $stmt->bindParam(':email',$email);
                                    $stmt->bindParam(':username',$uname);
                                    $stmt->bindParam(':psw',$psw);

                                    $result = $stmt->execute();

                                    if($result > 0){
                                        ?>
                                        <div>
                                            <div class="alert alert-success alert-dismissable fade in">
                                                <a href="category_course.php" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                <strong>Success!</strong> <p align="center" style="font-family: cursive;color: black">Successfully Registered..!</p>
                                            </div>
                                        </div>             
                                        <?php   } else{    ?>
                                        <div>
                                            <div class="alert alert-warning alert-dismissable fade in">
                                                <a href="category_course.php" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                <strong>Warning!</strong> <p align="center" style="font-family: cursive;color: black">Something went wrong..Try again..!</p>
                                            </div>
                                        </div> 
                                        <?php   }  

                                    }else{  
                                        ?>
                                        <div>
                                            <div class="alert alert-warning alert-dismissable fade in">
                                                <a href="category_course.php" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                <strong>Warning!</strong> <p align="center" style="font-family: cursive;color: black">Username already existing..!</p>
                                            </div>
                                        </div> 
                                        <?php
                                    }

                                }catch(PDOException $e){
                                    echo "ERROR: ".$e->getMessage();
                                }
                                $conn = null; 

                            }

                            ?>
                            <h1>New account</h1>

                            <p class="lead">Not our registered customer yet?</p>
                        <!-- <p>With registration with us new world of fashion, fantastic discounts and much more opens to you! The whole process will not take you more than a minute!</p>
                        <p class="text-muted">If you have any questions, please feel free to <a href="contact.html">contact us</a>, our customer service center is working for you 24/7.</p> -->

                        <hr>

                        <form method="post" enctype="multipart/form-data" action="register.php" >
                            <div class="row">
                                <div class="col-md-6 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <label for="name">Name</label>
                                        <input type="text" class="form-control" id="name" name="txtName" placeholder="Name" required>
                                        <span id="nameerrormsg"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <label for="phone">Phone</label>
                                        <input type="text" class="form-control" id="Phone" name="txtPhone" maxlength="10" placeholder="Phone Number" required />
                                        <span id="phoneerrormsg"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                        <label for="name">Address</label>
                                        <textarea name="txtAddress" id="address" class="form-control" rows="5" cols="5" required="required" placeholder="Address" required></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                       <label for="email">Email</label>
                                       <input type="email" class="form-control" id="Email" name="txtEmail" placeholder="Email ID" required><span id="emailerrormsg" value="0"></span>
                                   </div>
                               </div>
                           </div>
                           <div class="row">
                            <div class="col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <label for="name">User Name</label>
                                    <input type="text" class="form-control" id="uname" name="txtUname" placeholder="UserName" required><span id="usererrormsg"></span>
                                </div>
                            </div>                            
                            <div class="col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <input type="password" class="form-control" id="password" name="txtPassword" placeholder="Password with 8 characters" required><span id="passworderrormsg"></span>
                                </div>
                            </div>
                        </div>       

                        <div class="text-center">
                            <button type="submit" name="submit" class="btn btn-primary submitBtn"><i class="fa fa-user"></i>Register</button>  
                        </div>
                               <!--  <div id="buttonreplacement" style="display:none;">  
                                    <img src="img/AjaxLoader.gif" alt="loading..." width="70" height="70" class=" pull-right"/>
                                </div> -->
                            </form>

                        </div>
                    </div>


                    <div class="col-md-6 col-sm-12 col-xs-12">
                        <div class="box">
                            <?php
                            error_reporting(0);
                            $wrongid = $_GET['wrongid'];
                            if($wrongid == 1){
                                echo '<div>
                                <div class="alert alert-warning alert-dismissable fade in ">
                                    <a href="register.php" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <strong>Warning!</strong> <p align="center">Incorrect Email Id or Password.!</p>
                                </div>
                            </div>';
                        }
                        ?>
                        <h1>Login</h1>

                        <p class="lead">Already our customer?</p>
                        
                        <hr>

                        <form action="login.php" method="post">
                            <div class="form-group">
                                <label for="email">USERNAME</label>
                                <input type="text" class="form-control" id="Email" placeholder="Enter Username" name="txtUname" required="">
                            </div>
                            <div class="form-group">
                                <label for="password">PASSWORD</label>
                                <input type="password" class="form-control" id="password" name="txtPassword" placeholder="Enter Password with 8 characters" required>
                            </div>
                            <div class="text-center">
                                <button type="submit" name="login" class="btn btn-primary"><i class="fa fa-sign-in"></i> Log in</button>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#" name="reset" id="reset" align="right">Forgot Password?</a>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
            <!-- /.container -->
            <div class="push"></div>
        </div>
        <!-- /#content -->

        <div id="myModal" class="modal">
          <!-- Modal content -->
          <div class="modal-content">
            <div class="modal-header">
                <span class="close" style="margin-top: 23px;">&times;</span>
                <h2>Reset Your Password</h2>
            </div>
            <div class="modal-body">
                <form action="forgotpsw.php" method="POST">
                    <table align="center">
                        <label for="mail"><b> Email Id</b></label>
                        <input type="email" name="eid" id="email" placeholder="Your Email ID" required><span id="emailerror" value="0"></span>
                        <br>
                        <label for="new"><b>New Password</b></label>
                        <input type="password"  name="npsw" id="pass" placeholder="Create new Password with 8 characters" required><span id="passworderror"></span>
                        <br>
                        <!-- <label for="confirm"><b>Confirm Password</b></label>
                        <input type="password" name="cpsw" id="pass" placeholder="Password with 8 characters" required><span id="passworderror"></span> -->
                        <tr>
                            <td colspan="2" align="center">
                                <input type="submit" value="Reset" name="reset" id="id" class="btn btn-info" required>
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
    </div>



        <!-- *** COPYRIGHT ***
        _________________________________________________________ -->
        <?php
        include('footer.php');
        ?>
        <!-- *** COPYRIGHT END *** -->



    </div>
    <!-- /#all -->


    <!--- =================Javascripts files ==================-->
    <script type="text/javascript">
            // Get the modal
            var modal = document.getElementById('myModal');
            // Get the button that opens the modal
            var btn = document.getElementById("reset");
            // Get the <span> element that closes the modal
            var span = document.getElementsByClassName("close")[0];
            // When the user clicks the button, open the modal 
            btn.onclick = function() {
                modal.style.display = "block";
            }
            // When the user clicks on <span> (x), close the modal
            span.onclick = function() {
                modal.style.display = "none";
            }
            // When the user clicks anywhere outside of the modal, close it
            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                }
            }
        </script>
   <!--      <script type="text/javascript">
            $(function(){
               $("#pass").blur(function(){
                    var password = $("#pass").val();
                    if(password.length < 8){
                        $("#passworderror").html('<font color="red">Password must have 8 or more characters long..!</font>'); 
                    }else{
                        $("#passworderror").html('<font color="#cc0000"></font>'); 
                     }
                });
            })
        </script> -->
        <script type="text/javascript">
            window.setTimeout(function () {
                $(".alert-success").fadeTo(500, 0).slideUp(500, function () {
                    $(this).remove();
                });
            }, 3000);
            window.setTimeout(function () {
                $(".alert-warning").fadeTo(500, 0).slideUp(500, function () {
                    $(this).remove();
                });
            }, 3000);
        </script>
        <script src="js/jquery-1.11.0.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.cookie.js"></script>
        <script src="js/waypoints.min.js"></script>
        <script src="js/modernizr.js"></script>
        <script src="js/bootstrap-hover-dropdown.js"></script>
        <script src="js/owl.carousel.min.js"></script>
        <script src="js/front.js"></script>
        <script src="js/validation.js"></script>

    </body>

    </html>
