<!DOCTYPE html>
<html lang="en">

<?php
include('header.php');
// Database connection part
require("dbhelper.php");
?>

<body class="mainpagebg">
 <div class="overlay">
   <!-- *** TOPBAR ***
 __________
 _______________________________________________ -->

    <!-- *** NAVBAR ***
    _________________________________________________________ -->

    <div class="navbar navbar-default yamm navbar-fixed-top" role="navigation" id="navbar">
     <div class="container">
      <div class="navbar-header">
       <!-- <a class="navbar-brand home" href="index.php" data-animate-hover="shake"> -->
        <!-- <h3 style="font-family: cursive;">E~<span style="color: #428bca">Book</span>Rental</h3> -->
      <a href="index.php" >
        <img src="img/logo.png" alt="E-BookRental" data-animate-hover="shake"> 
      </a>

      <div class="navbar-buttons">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation">
         <span class="sr-only">Toggle navigation</span>
         <i class="fa fa-align-justify"></i>
       </button>
       <!-- <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#search">
         <span class="sr-only">Toggle search</span>
         <i class="fa fa-search"></i>
       </button>
       <a class="btn btn-default navbar-toggle" href="basket.html">
         <i class="fa fa-shopping-cart"></i>  <span class="hidden-xs">3 items in cart</span>
       </a> -->
     </div>
   </div>

   <!-- navbar-header -->
   <div class="navbar-collapse collapse right" id="navigation">
    <ul class="nav navbar-nav navbar-right">
      <li class="active"><a id="bg">Home</a></li> 
      <li><a id="bg" href="register.php">Register/Login</a></li> 
      <li><a id="bg" href="#books">Books</a></li> 
      <li><a id="bg" href="category.php">Category</a></li>      
    </ul>     
  </div>
  <!--/.nav-collapse -->
</div>
<!-- /.container -->
</div>
<!-- /#navbar -->

<!-- *** NAVBAR END *** -->

<div class="container" style="margin-top: 70px;">
 <!-- <h2>Carousel Example</h2> -->
 <div id="myCarousel" class="carousel slide" data-ride="carousel">
   <!-- Indicators -->
   <ol class="carousel-indicators">
     <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
     <li data-target="#myCarousel" data-slide-to="1"></li>
     <li data-target="#myCarousel" data-slide-to="2"></li>
   </ol>

   <!-- Wrapper for slides -->
   <div class="carousel-inner">
     <div class="item active">
       <img src="img/slide-books4.jpg" alt="bookslider4" style="width:100%;">
       <div class="carousel-caption">
         <!-- <h3>Best place to buy books</h3> -->
       </div>
     </div>
     <div class="item">
      <img src="img/slide-books3.jpg" alt="bookslider3" style="width:100%;">
      <div class="carousel-caption">

      </div>
    </div>
    <div class="item">
      <img src="img/slide-books1.jpg" alt="bookslider1" style="width:100%;">
      <div class="carousel-caption"></div>
    </div>
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
   <span class="fa fa-angle-left" style="font-size: 80px;margin-top: 180px;"></span>
   <span class="sr-only">Previous</span>
 </a>
 <a class="right carousel-control" href="#myCarousel" data-slide="next">
   <span class="fa fa-angle-right" style="font-size: 80px;margin-top: 180px;"></span>
   <span class="sr-only">Next</span>
 </a>
</div>
</div>

<br><br>

<!-- *** ADVANTAGES HOMEPAGE ***
  _________________________________________________________ -->
  <div id="all">

    <div id="content">

      <div id="advantages">

        <div class="container">
          <div class="same-height-row">
            <div class="col-sm-4">
              <div class="box same-height">
                <div class="icon"><i class="fa fa-heart"></i>
                </div>

                <h3 style="color: #4fbfa8"><b>We love our <br>customers</b></h3>
                <p>We are known to provide best possible services.</p>
              </div>
            </div>

            <div class="col-sm-4">
             <div class="box same-height">
               <div class="icon"><i class="fa fa-tags"></i>
               </div>

               <h3 style="color: #4fbfa8"><b>We offer you with <br> discounted prices</b></h3>
               <p>The provided services will be worth.</p>
             </div>
           </div>

           <div class="col-sm-4">
            <div class="box same-height">
              <div class="icon"><i class="fa fa-thumbs-up"></i>
              </div>

              <h3 style="color: #4fbfa8"><b>100% satisfaction guaranteed</b></h3>
              <p>Free returns on everything for 3 months.</p>
            </div>
          </div>
        </div>
        <!-- /.row -->
      </div>
    </div>

    <!-- *** ADVANTAGES END *** -->
    <div id="books"> <br><br></div>
<!-- *** Books From Database  ***
  _________________________________________________________ -->

  <?php
  try{
      // $start=0;
      // $end=4;
    $sql = $pdo->prepare("SELECT cat.categoryid,cat.categoryname,c.courseid,c.coursename,b.bookid,b.category,b.course,b.bookname,b.bookimage,b.author,b.price,b.stock FROM tblbooks b,tblcategory cat, tblcourse c WHERE cat.categoryid=b.category AND c.courseid=b.course LIMIT 0, 4");
      // $sql->bindParam(1,$start,PDO::PARAM_INT);
      // $sql->bindParam(2,$end,PDO::PARAM_INT);
    $sql->execute();   
      // $result = $pdo->query($sql);
    $count=$sql->rowCount();
    if($count > 0){

      ?>
      <div class="container">
       <div id="hot" class="books">
         <div class="overlay">
           <div class="box">
             <div class="container">
               <div class="col-md-12">
                 <h2 style="color: #428bca" data-animate-hover="bounce"><b>Books</b></h2>
               </div>
             </div>
           </div>
         </div>
       </div>


       <div class="container">
        <div class="row">

          <?php        
          while($row = $sql->fetch()){ 
           $bid=$row['bookid'];
           echo "<div class='col-sm-3 margin-small'>";
           echo "<div class='panel panel-primary' align='center'>";
           echo "<div class='panel-heading'>";
           echo "<a href='detail.php?bid=$bid'><img src='admin/book_images/".$row['bookimage']."' style='height: 200px;width:150px;padding-top: 10px;' alt='' class='img-responsive'></a>";
           echo "</div>";
           echo "<div class='panel-body' align='center'>";
           echo "<h4 style='text-align:center;'>".$row['categoryname']."-".$row['coursename']."</h4>";
           echo "<h4 style='text-align:center;'>".$row['bookname']."</h4>";
           echo "<h4 style='text-align:center;'>Rs.".$row['price']."</h4>";
           echo "</div>";
           echo "<div class='panel-footer'>";
           if($row['stock'] > 0){
            echo "<a href='customerbooks.php' class='btn btn-primary '><i class='fa fa-shopping-cart'></i> Add to cart</a> 
            <a href='customerbooks.php' class='btn btn-default '><i class='fa fa-heart'></i> </a>";

                                    // echo "<h5 style='text-align:center;color:green;'><b>Book Available</b></h5>";
          }else{
            echo "<h5 style='text-align:center;color:red;'><b>Book Not Avaliable</b></h5>";
          }
          echo "</div>";
          echo "</div>";
          echo "</div>";
        }
        ?>
      </div>
      <div class="margin-small" style="text-align:center;margin-top: 5px;margin-right: 50px;">
       <a class="btn btn-primary" href="category.php">VIEW MORE</a>
       <!-- <button class="btn btn-primary" onclick="window.location.href='indexview.php'">View more</button> -->
       <!-- <a id="faiconstyle" href="#carousel-example-generic" data-slide="prev" style="color:white;background-color: #4fbfa8;">View more</a> & -->
     </div>

     <?php
   } else {
    echo "<h3 style='text-align: center;'>No Book Details</h3>";
  }
} catch(PDOException $e){
  die("ERROR: Could not able to execute $sql. " . $e->getMessage());
}
?>

</div>  
</div> 

<!--   Book end -->

<div class="push"></div>
</div>  <!-- /#content --> 


<!-- Copyrights -->
<?php
include('footer.php');
?>

</div><!-- /#all -->


<!-- *** SCRIPTS TO INCLUDE ***
  _________________________________________________________ -->
  <script src="js/jquery-1.11.0.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.cookie.js"></script>
  <script src="js/waypoints.min.js"></script>
  <script src="js/modernizr.js"></script>
  <script src="js/bootstrap-hover-dropdown.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/front.js"></script>

</div>
</body>
</html>