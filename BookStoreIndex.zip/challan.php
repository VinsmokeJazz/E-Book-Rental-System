<?php
	session_start();
	// echo "customer is ".$_SESSION["cid"];
	if ($_SESSION["cid"] == NULL){
		header('location: register.php');
	}
	$userID = $_SESSION["cid"];
	$name= $_SESSION["name"];
?>
<!DOCTYPE html>
<html lang="en">

<?php
include('header.php');
// Database connection part
require("dbhelper.php");
?>

<body>
    <!-- *** NAVBAR ***
 _________________________________________________________ -->

    <div class="navbar navbar-default yamm " role="navigation" id="navbar">
        <div class="container">
            <div class="navbar-header">
               <a href="customerbooks.php" >
                    <img src="img/logo.png" alt="E-BookRental" data-animate-hover="shake"> 
                </a> 
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation">
                        <span class="sr-only">Toggle navigation</span>
                        <i class="fa fa-align-justify"></i>
                </button>
            </div>
            <!--/.navbar-header -->

            <div class="navbar-collapse collapse right" id="navigation">
                <ul class="nav navbar-nav navbar-right">
                	<li class="active"><a><span class="fa fa-user"></span> Hi, <?php echo $name ?></a></li> 
                	<li><a id="bg" href="logout.php">Logout</a></li> 
                </ul>
                
            </div>
            <!--/.nav-collapse -->
        </div>
    </div>

    <?php
        if (isset($_POST['getchallan'])){

            $totalamt=$_SESSION['GrandTotal'];
 
            $challansql = $pdo->prepare("INSERT INTO tblchallan(challanid,userid,totalamount) VALUES (NULL,:userid,:total)");
            $challanresult = $challansql->execute(array(":userid"=>$userID,":total"=>$totalamt));
            $challanlast_id = $pdo->lastInsertId();

            // $challansql = $pdo->query("SELECT challanid FROM tblchallan ORDER BY challanid DESC LIMIT 1");
            // $challanid = $challansql->fetchColumn();

            $storesql = $pdo->prepare("SELECT b.bookid,s.userid,s.bookid,s.qty,s.totalamount FROM tblstore s,tblbooks b WHERE s.userid=:userid AND s.bookid=b.bookid");
            $storesql->bindParam(":userid",$userID);
            $storesql->execute();
            
            while($row=$storesql->fetch()){ 
                $bookid=$row['bookid'];
                $qty=$row['qty'];
                $totalamount=$row['totalamount'];

                $sql = $pdo->prepare("INSERT INTO tblorderbook(orderid,userid,bookid,challanid,qty,totalamount) VALUES 
                    (NULL,:userid,:bookid,:challanid,:qty,:totalamount)");
                $sql->bindParam(":userid",$userID);
                $sql->bindParam(":bookid",$bookid);
                $sql->bindParam(":challanid",$challanlast_id);
                $sql->bindParam(":qty",$qty);
                $sql->bindParam(":totalamount",$totalamount);
                $result = $sql->execute();
            }
            

    ?>
    <div id="content">
        <div class="container">
            <div class="row">
                <form action="finishchallan.php" method="POST" target="_blank" class="formsubmit">
                    <div class="col-md-6 col-sm-12 col-xs-12">
                        <div class="box">
                            <h1>CHALLAN</h1>
                            <input type="hidden" name="challanid" class="form-control" id="challanid" value="<?php echo $challanlast_id; ?>" >
                            <div class="row">
                                <div class="col-md-12 col-sm-12 col-xs-12" >
                                    <h4>Your Unique Challan Number ==> <u style="color: red"><span style="color: red;padding-left: 8px;"> <?php echo $challanlast_id; ?> </span></u> </h4>
                                </div>
                            </div><br>
                            <div class="row">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <h4>Total amount to be paid ==> <b>Rs. <?php echo $totalamt; ?></b></h4>
                                </div>
                            </div><br>
                            <div class="row">
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <h5> Challan created date </h5>
                                    <input type="text" name="startDate" class="form-control" id="stMin" value="<?php echo date('D, M d, Y'); ?>" readonly>
                                    <?php $srtMin = strtotime("+1 day"); ?>
                                    <input type="hidden" name="stDate" class="form-control" id="setMin" value="<?php echo date('D, M d, Y', $srtMin); ?>" >
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <h5>Challan Expiry Date</h5>
                                    <?php $expdate = strtotime("+7 day"); ?>
                                    <input type="text" name="expDate" class="form-control" id="setMax" value="<?php echo date('D, M d, Y', $expdate); ?>" readonly>
                                </div>
                            </div>
                        </div>  
                        <div class="box-footer">
                            <div class="pull-right">
                                <button type="submit" name="print" class="btn btn-primary">Finish <i class="fa fa-chevron-right"></i></button>
                            </div>
                        </div>      
                    </div>
                    <div class="col-md-6 col-sm-12 col-xs-12">
                        <div class="box">
                            <h1>Appointment details</h1>
                            <div class="row">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="form-group">    
                                        <h5>Select your appointment date</h5>
                                        <input type='text' name="appdate" class="form-control" id="datepicker" placeholder="Select Date" required="" />
                                        <input type='hidden' id='getday'  ><br/>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="form-group">        
                                        <h5>Select Time slots</h5>
                                        <select class="form-control" name="timeslot" id="example-select" required=""><option>Select Timings</option></select>
                                    </div>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <p><h4>Note:</h4>Choose your Appointment date and respective Time Slots.</p>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    
    <?php 
        // $sql=$pdo->prepare("DELETE FROM tblchallan WHERE userid=:userid ");
        // $sql->bindParam(":userid",$userID);
        // $sql->execute();
        $sql = $pdo->prepare("SELECT s.bookid,b.bookid,s.qty,b.stock FROM tblstore s,tblbooks b WHERE s.bookid=b.bookid AND userid = :userid");
        $sql->execute(["userid"=>$userID]);
        while($row=$sql->fetch()){
            $Book=$row['bookid'];
            $qty=$row['qty'];
            $stock=$row['stock'];

            $stock=$stock-$qty;
        
            $sql1=$pdo->prepare("UPDATE tblbooks SET stock=:stock WHERE bookid=:bookid");
            $sql1->bindParam(":stock",$stock);
            $sql1->bindParam(":bookid",$Book);
            $sql1->execute();
        }

        $sql=$pdo->prepare("DELETE FROM tblstore WHERE userid=:userid ");
        $sql->bindParam(":userid",$userID);
        $sql->execute();

    }
    ?>
    
    <!-- *** SCRIPTS TO INCLUDE ***
    _________________________________________________________ -->
    <script src="js/jquery-1.11.0.min.js"></script>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.cookie.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/modernizr.js"></script>
    <script src="js/bootstrap-hover-dropdown.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/front.js"></script>
    <!-- My javasript ajax code -->
    <script src="js/myjs.js"></script>
    <script src="js/jquery.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#datepicker').datepicker({
                dateFormat: "yy-mm-dd", 
                /* dateFormat: "dd-mm-yy",  */
                maxDate:'+1m +10d',
                minDate: -10
            });

             // Changing date range
             /* $('#setMin,#setMax').change(function(){ */
            $('#datepicker').click(function(){
                // Get value
                var minDate = $("#setMin").val();
                var maxDate = $("#setMax").val();

                // Destroy 
                $('#datepicker').datepicker('destroy');

                // Initialize
                $('#datepicker').datepicker({
                    dateFormat: "yy-mm-dd", 
                });

                // Set minDate and maxDate
                if(minDate != ''){
                    $('#datepicker').datepicker('option', 'minDate', new Date(minDate));
                }
             
                if(maxDate != ''){
                    $('#datepicker').datepicker('option', 'maxDate', new Date(maxDate));
                }
            });
               
            /* $('#getday').focus(function(){ */
            $('#datepicker').change(function(){
                var select = document.getElementById("example-select");
                select.options.length = 0;
                var weekday = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
                dateVar = new Date( $("#datepicker").val());
                $('#getday').val(dateVar.getDay());  

                if($(getday).val()==0){
                    var myobject = {
                            'Its Sunday' : 'Holiday'

                    };
                }else if($(getday).val()==6){
                    var myobject = {
                        'Select' : 'Select Timings',
                        '10 A.M - 11 A.M' : '10 A.M - 11 A.M',
                        '11 A.M - 12 P.M' : '11 A.M - 12 P.M',
                        '12 P.M - 1 P.M' : '12 P.M - 1 P.M'
                    };

                }else{
                    var myobject = {
                        'Select' : 'Select Timings',
                        '10 A.M - 11 A.M' : '10 A.M - 11 A.M',
                        '11 A.M - 12 P.M' : '11 A.M - 12 P.M',
                        '12 P.M - 1 P.M' : '12 P.M - 1 P.M',
                        '2 P.M - 3 P.M' : '2 P.M - 3 P.M',
                        '3 P.M - 4 P.M' : '3 P.M - 4 P.M',
                    };
                } 
                var select = document.getElementById("example-select");
                for(index in myobject) {
                    select.options[select.options.length] = new Option(myobject[index], index);
                }
            });
        });
    </script>
    <script type="text/javascript">
        $('.formsubmit').on('submit',function(){
            // var self=$(this);
            // button=self.find('input[type="submit"],button');
            // button.attr('disabled','disabled').val('Finished');
            setTimeout(function() {
            window.location.href = "customerbooks.php";
            }, 1000);
            //Window.location.href='customerbooks.php'
        });
    </script>
</body>
</html>