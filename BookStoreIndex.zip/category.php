<!DOCTYPE html>
<html lang="en">

<?php
include('header.php');
// Database connection part
require("dbhelper.php");
?>

<body>
    <!-- *** NAVBAR ***
    _________________________________________________________ -->

    <div class="navbar navbar-default yamm navbar-fixed-top" role="navigation" id="navbar">
    	<div class="container">
    		<div class="navbar-header">
    			<a href="index.php" >
    				<img src="img/logo.png" alt="E-BookRental" data-animate-hover="shake"> 
    			</a>
    			&nbsp;&nbsp;&nbsp; 
    			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation" id="togglesearch">
    				<span class="sr-only">Toggle navigation</span>
    				<i class="fa fa-align-justify"></i>
    			</button>
    			<div>
    				<ul class="nav navbar-nav navbar-toggle">
    					<li><input type="text" class="form-control" id="searchToggle" placeholder="Search Books"/></li>
    				</ul>
    			</div>
    		</div>
    		<!--/.navbar-header -->
    		<div class="navbar-collapse collapse" style="margin-top: 22px;">
    			<ul class="nav navbar-nav ">
    				<li><input type="text" class="form-control" id="search" placeholder="Search Books"/></li>
    				<!-- <li style="left: 15px"><button class="btn btn-primary" id="searchbtn">Search</button></li> -->
    			</ul>
    		</div>
    		<div class="navbar-collapse collapse right" id="navigation">

    			<ul class="nav navbar-nav navbar-right">
    				<li><a id="bg" href="index.php">Home</a></li> 
    				<li><a id="bg" href="register.php">Register/Login</a></li>
    				<li class="active"><a>Category</a></li>
                   <!--  <ul class="nav navbar-nav" style="margin-top: 20px;" id="searchdetails">
		            	<li><input type="text" class="form-control" id="search" style="margin-left: 25px;width: 90%;" /></li>
		                <li style="left: 15px"><button class="btn btn-primary" id="searchbtn">Search</button></li>
		            </ul> -->   
		        </ul>

		    </div>
		    <!--/.nav-collapse -->


		    <!--/.nav-collapse -->
		</div>
		<!-- /.container -->
	</div>
	<!-- /#navbar -->

	<!-- *** NAVBAR END *** -->

	<div id="content" style="margin-top: 80px">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">
					<ul class="breadcrumb">
						<li><a href="index.php">Home</a>
						</li>
						<li>View more</li>
					</ul>
				</div>
			</div>

			<div class="row">
				<!-- <div class="col-md-1"></div> -->
				<div class="col-md-2 col-sm-12 col-xs-12">
					<div id="get_category"></div>
				</div>
				<!-- 	<div class="col-md-1"></div> -->
				<div class="col-md-10 col-sm-12 col-xs-12">
					<div class="panel panel-primary">
						<div class="panel-heading">Books</div>
						<div class="panel-body">
							<div id="get_books"></div>
						</div>
						<!-- <div class="panel-footer">&copy; <script>document.write(new Date().getFullYear())</script> | E-BookRental, Online Book Store
					</div> -->
				</div>
			</div>
		</div>
	</div>

          <!-- *** Books From Database  ***
          _________________________________________________________ -->
          <div class="push"></div>
      </div> <!--content -->


<!-- *** COPYRIGHT ***
	_________________________________________________________ -->
	<?php
	include('footer.php');
	?>

	<!-- *** COPYRIGHT END *** -->

	<!-- /#all -->

</div>


<!-- *** SCRIPTS TO INCLUDE ***
	_________________________________________________________ -->
	<script src="js/jquery-1.11.0.min.js"></script>
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.cookie.js"></script>
	<script src="js/waypoints.min.js"></script>
	<script src="js/modernizr.js"></script>
	<script src="js/bootstrap-hover-dropdown.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/front.js"></script>
	<!-- My javasript ajax code -->
	<script src="js/myjs.js"></script>

	<script type="text/javascript">
		$(document).ready(function(){
			$("#searchdetails").hide();
			$("#togglesearch").click(function(){
				$("#searchdetails").show();
			});
			$("#searchdetails").hide();
		});
	</script>

</body>

</html>