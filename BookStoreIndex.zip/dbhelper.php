<?php
// error_reporting(0);
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bookrent";
try{
	$pdo = new PDO("mysql:host=$servername;dbname=$dbname", "$username", "$password");
								// Set the PDO error mode to exception
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}catch(PDOException $e){
	die("ERROR: Could not connect. " . $e->getMessage());
}
?>