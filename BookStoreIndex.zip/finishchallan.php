<!DOCTYPE html>
<html lang="en">
<?php
include('header.php');

require("dbhelper.php");
require("fpdf/fpdf.php");
session_start();
	// echo "customer is ".$_SESSION["cid"];
if ($_SESSION["cid"] == NULL){
	header('location: register.php');
}
$userid = $_SESSION["cid"];
$name= $_SESSION["name"];

$image="logo.png";

if(isset($_POST['print'])){
	$appointment_date=$_POST['appdate'];
	$ReturnDate = date('Y-m-d', strtotime("+3 months", strtotime($appointment_date)));
	$appointment_date1=date("d-m-Y", strtotime($_POST['appdate']));
	$slot=$_POST['timeslot'];
	$challanid=$_POST['challanid'];
	// echo $appointment_date;
	// echo "ss:".$slot;
	if($slot=='ValueB'){
		$slot='10am-11am';
	}else if($slot=='ValueC'){
		$slot='11am-12pm';
	}else if($slot=='ValueD'){
		$slot='12pm-1pm';
	}else if($slot=='ValueE'){
		$slot='2pm-3pm';
	}else if($slot=='ValueF'){
		$slot='3pm-4pm';
	}else{
		//alert("Select time slot");
	}
	$start_date=date("Y-m-d");
	$start_date1=date("d-m-Y");
	$end=strtotime("+7 day");
	//echo $start_date;
	$end_date= date("Y-m-d", $end );
	$end_date1=date("d-m-Y", $end);
	// $appointment_date1=date("d-m-Y", $appointment_date);
	
	//echo "hjhjh:".$end_date;
	//echo "id:".$challanid;
	
	$sql=$pdo->prepare("UPDATE tblchallan SET appointment_date=:appointment_date, return_date=:ReturnDate,
		time_slot=:slot, 
		start_date=:start_date, 
		end_date=:end_date WHERE userid=:userid AND challanid=:challanid"
		);
	
	$sql->bindParam(":appointment_date",$appointment_date);
	$sql->bindParam(":ReturnDate",$ReturnDate);
	$sql->bindParam(":slot",$slot);
	$sql->bindParam(":userid",$userid);
	$sql->bindParam(":challanid",$challanid);
	$sql->bindParam(":start_date",$start_date);
	$sql->bindParam(":end_date",$end_date);
	$sql->execute();

}

$pdf=new FPDF('p','mm','A4');

$pdf->AddPage();
	//set font to arial
$pdf->SetFont('Arial','I',10);

$pdf->Cell(130,5,'[Please carry this challan to collect book]',0,0);
$pdf->Cell(50,10,'Place:Near KSRTC Bus stand, Mangalore',0,1);
$pdf->Cell(130,5,'',0,0);
$pdf->Cell(50,10,'Contact No: 0467-2236547',0,1);

$pdf->Cell(130,10,'',0,1);
$pdf->Cell(130,5,'',0,1);
$pdf->Cell(130,5,'',0,1);

$pdf->Image($image,55,30,100,30,0);
$pdf->SetFont('Arial','I',10);

$pdf->Cell(130,5,'',0,1);
$pdf->Cell(130,5,'',0,1);
$pdf->Cell(130,5,'',0,1);

$pdf->SetFont('Arial','',14);

$pdf->Cell(15,5,'',0,0);
$pdf->Cell(85,5,'Challan ID',0,0);
$pdf->Cell(10,5,':',0,0);
$pdf->Cell(130,5,$challanid,0,1);

$pdf->Cell(15,5,'',0,0);
$pdf->Cell(85,5,'User Name',0,0);
$pdf->Cell(10,5,':',0,0);
$pdf->Cell(130,5,$name,0,1);

$pdf->Cell(15,5,'',0,0);
$pdf->Cell(85,5,'Challan Created Date',0,0);
$pdf->Cell(10,5,':',0,0);
$pdf->Cell(25,5,$start_date1,0,1);

$pdf->Cell(15,5,'',0,0);
$pdf->Cell(85,5,'Challan End Date',0,0);
$pdf->Cell(10,5,':',0,0);
$pdf->Cell(25,5,$end_date1,0,1);

$pdf->Cell(15,5,'',0,0);
$pdf->Cell(85,5,'Appointment Date',0,0);
$pdf->Cell(10,5,':',0,0);
$pdf->Cell(25,5,$appointment_date1,0,1);

$pdf->Cell(15,5,'',0,0);
$pdf->Cell(85,5,'Appointment Time',0,0);
$pdf->Cell(10,5,':',0,0);
$pdf->Cell(59,5,$slot,0,1);
$pdf->Cell(130,5,'',0,1);
$pdf->Cell(130,5,'',0,1);

	//Making dummy empty cell
$pdf->Cell(189,10,'Your Book Details:',0,1);

$pdf->Cell(15,5,'Sl.No.',1,0);
$pdf->Cell(80,5,'Book Name:',1,0);
$pdf->Cell(30,5,'Quantity',1,0);
$pdf->Cell(59,5,'Price',1,1);

$totalamount=0;	
$i=1;	
$sql = $pdo->prepare("SELECT o.bookid,b.bookid,b.bookname,b.price,o.qty,o.totalamount, c.challanid, o.challanid,c.userid FROM tblorderbook o,tblbooks b,tblchallan c WHERE o.bookid=b.bookid AND c.challanid=o.challanid AND c.userid = :userid AND o.challanid=:challanid");
$sql->execute(["userid"=>$userid,
	"challanid"=>$challanid]);

if($sql->rowCount() > 0){
	while ($row=$sql->fetch()) {
		$bookid=$row['bookid'];
		$bookname=$row['bookname'];
		$challanid=$row['challanid'];
			//$username=$row['username'];

			//$appointment_date=$row['appointment_date'];
			//$slot=$row['slot'];
		$qty=$row['qty'];
		$price=$row['totalamount'];
		$totalamount=$totalamount+$price;


		$pdf->Cell(15,5,$i,1,0);
		$pdf->Cell(80,5,$bookname,1,0);
		$pdf->Cell(30,5,$qty,1,0,'R');
		$pdf->Cell(59,5,$price,1,1,'R');
		$i=$i+1;
	}}
	
	$pdf->Cell(95,5,'',0,1);
	$pdf->Cell(95,5,'',0,0);
	$pdf->Cell(30,5,'Grand Total:',0,0);
	$pdf->Cell(59,5,'Rs.'.$totalamount.'/-',0,0,'R');
	
	$pdf->Cell(130,5,'',0,1);
	$pdf->Cell(130,5,'',0,1);
	$pdf->Cell(130,5,'',0,1);
	$pdf->SetFont('Arial','',12);
	$pdf->Cell(130,5,'------------------------------------------------- Kindly Note ---------------------------------------------------------',0,1);
	$pdf->Cell(130,5,'1. The books should be returned by 3 months from collected date.',0,1);
	$pdf->Cell(130,5,'2. If failed to return the books on time, fine of Rs.20/- is calculated for each book per day.',0,0);
	
	$pdf->Output();
	
	?>

<body>
</body>
</html>
