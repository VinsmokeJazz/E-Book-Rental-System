<?php
	session_start();
	// echo "customer is ".$_SESSION["cid"];
	if ($_SESSION["cid"] == NULL){
		header('location: register.php');
	}
	$userID = $_SESSION["cid"];
	$name= $_SESSION["name"];
?>
<!DOCTYPE html>
<html lang="en">

<?php
include('header.php');
// Database connection part
require("dbhelper.php");
?>

<body>
    <!-- *** NAVBAR ***
 _________________________________________________________ -->

    <div class="navbar navbar-default yamm navbar-fixed-top" role="navigation" id="navbar">
        <div class="container">
            <div class="navbar-header">
                <a href="customerbooks.php" >
                    <img src="img/logo.png" alt="E-BookRental" data-animate-hover="shake"> 
                </a>
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation">
                        <span class="sr-only">Toggle navigation</span>
                        <i class="fa fa-align-justify"></i>
                </button>
            </div>
            <!--/.navbar-header -->

            <div class="navbar-collapse collapse right" id="navigation">
                <ul class="nav navbar-nav navbar-right">
                	<li class="active"><a><span class="fa fa-user"></span> Hi, <?php echo $name ?></a></li> 
                	<li><a id="bg" href="customerbooks.php">Home</a></li> 
                	<li><a id="bg" href="logout.php">Logout</a></li> 
                </ul>
                
            </div>
            <!--/.nav-collapse -->
        </div>
        <!-- /.container -->
    </div>
    <!-- /#navbar -->
    <!-- *** NAVBAR END *** -->
    <div id="content" style="margin-top: 80px;">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <ul class="breadcrumb">
                        <li><a href="customerbooks.php">Home</a></li>
                        <li><a href="store.php">Store</a></li>
                        <li>Order Review</li>
                    </ul>
                </div>
            </div> 
            <?php
                $sql = $pdo->prepare("SELECT s.bookid,b.bookid,b.bookimage,b.bookname,b.price,s.qty,s.totalamount FROM tblstore s,tblbooks b WHERE s.bookid=b.bookid AND userid = :userid");
                $sql->execute(["userid"=>$userID]);
            ?>
            <div class="row">
                <div class="col-md-8 col-sm-12 col-xs-12">
                    <div class="box">
                        <form method="POST" action="challan.php">
                        <h1>Order Review</h1>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th >Book Name</th>
                                            <th>Image</th>
                                            <th>Price</th>
                                            <th>Quantity</th>
                                            <th>Total Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody >
                                        <?php
                                        if($sql->rowCount() > 0){
                                        $GrandTotal=0;
                                        while ($row=$sql->fetch()) {
                                            $bookid=$row['bookid'];
                                            $name=$row['bookname'];
                                            $image=$row['bookimage'];
                                            $price=$row['price'];
                                            $qty=$row['qty'];
                                            $totalamount=$row['totalamount'];
                                            $AmountArray = array($totalamount);
                                            $AmountSum=array_sum($AmountArray);
                                            $GrandTotal=$GrandTotal + $AmountSum;
                                        ?> 
                                        <tr>
                                       
                                        <td style='width:140px;'><?php echo $name ?></td>
                                            <?php echo "<td><img src='admin/book_images/$image' style='height: 80px;width:80px;' alt='book' class='img-responsive'></td>";?>
                                            <td><?php echo $price ?></td>
                                            <td><?php echo $qty ?></td>
                                            <td><?php echo $totalamount?></td>
                                        </tr>

                                        <?php $_SESSION['GrandTotal']=$GrandTotal;
                                        }   ?>
                                        <tfoot>
                                            <tr>
                                                <th colspan='4'>Grand Total</th>
                                                <th colspan='3' total='$GrandTotal'>Rs. <?php echo $GrandTotal ?></th>
                                            </tr>
                                        </tfoot>
                                        <?php 
                                        }   ?>
                                    </tbody>
                                </table>

                            </div>
                    
                            <div class="box-footer">
                                <div class="pull-left">
                                    <a href="store.php" class="btn btn-default"><i class="fa fa-chevron-left"></i>Back</a>
                                </div> 
                                <div class="pull-right">
                                    <button type="submit" name="getchallan" class="btn btn-primary">Generate Challan <i class="fa fa-chevron-right"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12 col-xs-12">
                   <div class="box">
                        <h1>Date Summary</h1>
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <h5>Challan Created Date</h5>
                                    <p id="demo"></p>
                                    <input type="text" name="startDate" class="form-control" id="startdate" value="<?php echo date('D, M d, Y'); ?>" readonly>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <div class="form-group">
                                    <p id="demo"></p>
                                    <?php $expdate = strtotime("+7 day"); ?>
                                    <h5>Challan Expiry Date</h5>
                                    <input type="text" name="expDate" class="form-control" id="expdate" value="<?php echo date('D, M d, Y', $expdate); ?>" readonly>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <p><h4>Note:</h4>The challan Expires in a week, Kindly Visit the Book Store to get your books.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-- *** SCRIPTS TO INCLUDE ***
    _________________________________________________________ -->
    <script src="js/jquery-1.11.0.min.js"></script>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.cookie.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/modernizr.js"></script>
    <script src="js/bootstrap-hover-dropdown.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/front.js"></script>
    <!-- My javasript ajax code -->
    <script src="js/myjs.js"></script>
    <script type="text/javascript">
        window.setTimeout(function () {
            $(".alert-success").fadeTo(500, 0).slideUp(500, function () {
                $(this).remove();
            });
        }, 1000);
    </script>
    <script>
        // var d = new Date();
        // var a = d.toDateString();
        // document.getElementById("strtdate").value=a;
    </script>
</body>
</html>
