
<?php
/* session_start();
	// echo "customer is ".$_SESSION["cid"];
if ($_SESSION["cid"] == NULL){
	header('location: register.php');
}
$userID = $_SESSION["cid"];
		// Database connection part */
require("dbhelper.php");
?>

<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>

	<?php
	if(isset($_POST['editacc'])){
$data=0;
	$name=$_POST["name"];
	$phone=$_POST["num"];
	$addr=$_POST["addr"];
	$mail=$_POST["mail"];
	$uname=$_POST["usern"];
	 /*  if($name==" " || $phone==" " ||$addr=" " || $mail=" " || $uname=" "){
		$data=0;
	}else{ */  
	
		$sql=$pdo->prepare("UPDATE tblusers SET name=:name, phone=:phone, address=:addr, email=:mail, username=:uname WHERE userid=:userid");
		$sql->bindParam(":name",$name);
		$sql->bindParam(":phone",$phone);
		$sql->bindParam(":addr",$addr);
		$sql->bindParam(":mail",$mail);
		$sql->bindParam(":uname",$uname);
		$sql->bindParam(":userid",$userID);
		$result=$sql->execute();
if($sql1->rowCount()>0){		
			echo '<script type="text/javascript">'; 
			echo 'alert("Successfully Updated");'; 
			echo 'window.location.href = "customerbooks.php";';
			echo '</script>';
		}else{
			echo '<script type="text/javascript">'; 
			echo 'alert("Failed");'; 
			echo 'window.location.href = "myaccount.php";';
			echo '</script>';
		} 
				// }else{
				// 	echo '<script type="text/javascript">'; 
				// 	echo 'alert("New Password and ConfirmPassword must match!!!");'; 
				// 	echo 'window.location.href = "register.php";';
				// 	echo '</script>';
				// }
			// }else{
			// 	echo '<script type="text/javascript">'; 
			// 	echo 'alert("Password length must be greterthan 8 ");'; 
			// 	echo 'window.location.href = "register.php";';
			// 	echo '</script>';
			// }
	}

	?>
</body>
<script src="js/validation.js"></script>
</html>

