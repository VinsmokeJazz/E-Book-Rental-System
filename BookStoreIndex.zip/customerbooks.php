<!DOCTYPE html>
<html lang="en">

<?php
session_start();
	// echo "customer is ".$_SESSION["cid"];
if ($_SESSION["cid"] == NULL){
	header('location: register.php');
}
$ID = $_SESSION["cid"];
$name= $_SESSION["name"];

include('header.php');
// Database connection part
require("dbhelper.php");
?>

<body>
    <!-- *** NAVBAR ***
    _________________________________________________________ -->

    <div class="navbar navbar-default yamm navbar-fixed-top" role="navigation" id="navbar">
    	<div class="container">
    		<div class="navbar-header">
    			<a href="customerbooks.php" >
    				<img src="img/logo.png" alt="E-BookRental" data-animate-hover="shake" width="250px"> 
    			</a>
    			&nbsp;&nbsp;&nbsp; 
    			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation" id="togglesearch">
    				<span class="sr-only">Toggle navigation</span>
    				<i class="fa fa-align-justify"></i>
    			</button>
    			<div>
    				<ul class="nav navbar-nav navbar-toggle">
    					<li><input type="text" class="form-control" id="LoginSearchToggle" placeholder="Search Books"/></li>
    				</ul>
    			</div>
    		</div>
    		<!--/.navbar-header -->
    		<div class="navbar-collapse collapse" style="margin-top: 22px;">
    			<ul class="nav navbar-nav ">
    				<li><input type="text" class="form-control" id="LoginSearch" placeholder="Search Books" /></li>
    				<!-- <li style="left: 15px"><button class="btn btn-primary" id="searchbtn">Search</button></li> -->
    			</ul>
    		</div>
    		<div class="navbar-collapse collapse right" id="navigation">
    			<ul class="nav navbar-nav navbar-right">
    				<li class="active"><a><span class="fa fa-user"></span> Hi, <?php echo $name ?></a></li> 
    				<li><a id="bg" href="customerbooks.php">Home</a></li>
    				<li class="dropdown">
    					<a href="#" id="cart_container" class="dropdown-toggle " data-toggle="dropdown"><span class="fa fa-shopping-cart"></span> Cart <span class="badge cartbadge"></span> </a>
    					<div class="dropdown-menu" style="width:400px;height:400px;overflow-y: scroll;">
    						<div class="container" style="width: 100%;">
    							<div class="panel panel-danger">
	                				<!-- <div style="float: right;">
	                					<a href="store.php" class="btn btn-danger "  >Proceed to Checkout <span class="fa fa-shopping-cart"></a>
	                				</div><br><br> -->
	                				<div class="panel-heading">
	                					<div class="row">
	                						<div class="col-md-3 col-sm-3 col-xs-3">Sl.No.</div>
	                						<div class="col-md-3 col-sm-3 col-xs-3">Image</div>
	                						<div class="col-md-3 col-sm-3 col-xs-3">Name</div>
	                						<div class="col-md-3 col-sm-3 col-xs-3">Price</div>
	                					</div>
	                				</div>
	                				<div class="panel-body">
	                					<div id="cart_books"></div>
	                				</div>
	                				
	                			</div>
	                		</div>
	                	</div>
	                </li>
	                <li class="wishcount"><a id="bg" href="wishlist.php" onclick="wishlist_avail()" class="wish"><span class="notification hidden-sm hidden-xs"></span><span id="notification-latest"></span>Wishlist  <span class="badge wishlistbadge" ></span></a></li>
	                <li><a id="bg" href="myaccount.php">My Account</a></li> 
	                <li><a id="bg" href="logout.php">Logout</a></li> 
	            </ul>
	        </div>
	        <!--/.nav-collapse -->
	    </div>
	    <!-- /.container -->
	</div>
	<!-- /#navbar -->

	<!-- *** NAVBAR END *** -->

	<div id="content" style="margin-top: 80px;">
		<div class="container">
			<div class="row">
				<div class="col-md-2 col-sm-12 col-xs-12">
					<div id="login_get_category"></div>
				</div>
				<div class="col-md-10 col-sm-12 col-xs-12">
					<div id="added"></div>
					<div class="panel panel-primary">
						<div class="panel-heading" style="border-bottom-width: 8px;">
							<h4 class="inline">Books</h4>
						</div>
						<div class="panel-body">
							<div id="login_get_books"></div>
						</div>
					</div>
				</div>
			</div>
			<!-- <div class="row">
				<div class="col-md-12">
					<center>
						<ul class="pagination" id="pageno">
							<li><a href="#">1</a></li>
						</ul>
					</center>
				</div>
			</div> -->
		</div>

          <!-- *** Books From Database  ***
          _________________________________________________________ -->

          <div class="push"></div>
      </div>  <!-- content -->


<!-- *** COPYRIGHT ***
	_________________________________________________________ -->
	<?php
	include('footer.php');
	?>

	<!-- *** COPYRIGHT END *** -->

	<!-- /#all -->

</div>


<!-- *** SCRIPTS TO INCLUDE ***
	_________________________________________________________ -->
	
	<script src="js/jquery-1.11.0.min.js"></script>
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.cookie.js"></script>
	<script src="js/waypoints.min.js"></script>
	<script src="js/modernizr.js"></script>
	<script src="js/bootstrap-hover-dropdown.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/front.js"></script>
	<!-- My javasript ajax code -->
	<script src="js/myjs.js"></script>

	<script type="text/javascript">
		$(document).ready(function(){
			$(".dropdown, .btn-group").hover(function(){
				var dropdownMenu = $(this).children(".dropdown-menu");
				if(dropdownMenu.is(":visible")){
					dropdownMenu.parent().toggleClass("open");
					$.ajax({
						url : "login_action.php",
						method : "POST",
						data : {get_cart_books:1},
						success : function(data){
							$("#cart_books").html(data);
						}
					})
				}
			});
		}); 

	
	</script>
	
</body>

</html>