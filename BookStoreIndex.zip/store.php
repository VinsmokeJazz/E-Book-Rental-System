<?php
session_start();
	// echo "customer is ".$_SESSION["cid"];
if ($_SESSION["cid"] == NULL){
  header('location: register.php');
}
$ID = $_SESSION["cid"];
$name= $_SESSION["name"];
?>
<!DOCTYPE html>
<html lang="en">

<?php
include('header.php');
// Database connection part
require("dbhelper.php");
?>

<body>
    <!-- *** NAVBAR ***
    _________________________________________________________ -->

    <div class="navbar navbar-default yamm navbar-fixed-top" role="navigation" id="navbar">
        <div class="container">
            <div class="navbar-header">
                <a href="customerbooks.php" >
                    <img src="img/logo.png" alt="E-BookRental" data-animate-hover="shake"> 
                </a> 
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation">
                    <span class="sr-only">Toggle navigation</span>
                    <i class="fa fa-align-justify"></i>
                </button>
            </div>
            <!--/.navbar-header -->

            <div class="navbar-collapse collapse right" id="navigation">
                <ul class="nav navbar-nav navbar-right">
                	<li class="active"><a><span class="fa fa-user"></span> Hi, <?php echo $name ?></a></li> 
                	<li><a id="bg" href="customerbooks.php">Home</a></li> 
                	<li><a id="bg" href="logout.php">Logout</a></li> 
                </ul>
                
            </div>
            <!--/.nav-collapse -->
        </div>
        <!-- /.container -->
    </div>
    <!-- /#navbar -->
    <!-- *** NAVBAR END *** -->
    <div id="content" style="margin-top: 80px;">
        <div class="container">
            <div class="row">
                <div class="col-md-9 col-sm-12 col-xs-12">
                    <ul class="breadcrumb">
                        <li><a href="customerbooks.php">Home</a></li>
                        <li>Cart</li>
                    </ul>
                </div>
            </div> 
            <div class="row">

            </div> 
            <div class="row">
                <div class="col-md-8 col-sm-12 col-xs-12">
                    <div class="box">
                        <h1>Cart</h1>
                        <p class="text-muted" id="NumOfRecords"></p>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th >Book Name</th>
                                        <th>Image</th>
                                        <th>Price</th>
                                        <th>Quantity</th>
                                        <th>Total Amount</th>
                                        <th colspan="2">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="storecheckout">


                                </tbody>
                            </table>
                        </div>
                        <div class="box-footer">
                            <div class="pull-left">
                                <a href="customerbooks.php" class="btn btn-default"><i class="fa fa-chevron-left"></i> Continue shopping</a>
                            </div>
                            <div class="pull-right">
                                <a href="#" class="btn btn-primary checkqty">Place Order <i class="fa fa-chevron-right"></i></a>
                                <!-- <button type="submit" class="btn btn-primary">Proceed to checkout <i class="fa fa-chevron-right"></i></button> -->
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-sm-12 col-xs-12">
                   <div class="box note" style="font-family:sans-serif;font-size:120%;">
                    <h1>Note</h1>
                        <!-- <p><i class='fa fa-check'></i> When you change the quantity of an item, please click UPDATE button.</p><br> -->
                        <p><i class='fa fa-check'></i> The total number of books should not exceed more than 15. </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-- *** SCRIPTS TO INCLUDE ***
    _________________________________________________________ -->
    <script src="js/jquery-1.11.0.min.js"></script>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.cookie.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/modernizr.js"></script>
    <script src="js/bootstrap-hover-dropdown.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/front.js"></script>
    <!-- My javasript ajax code -->
    <script src="js/myjs.js"></script>
    <script type="text/javascript">
        window.setTimeout(function () {
            $(".alert-success").fadeTo(500, 0).slideUp(500, function () {
                $(this).remove();
            });
        }, 1000);
    </script>
</body>
</html>
