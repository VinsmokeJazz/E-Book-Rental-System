<!DOCTYPE html>
<html lang="en">

<head>

	<meta charset="utf-8">
	<meta name="robots" content="all,follow">
	<meta name="googlebot" content="index,follow,snippet,archive">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Book Store Rental system">
	<!-- <meta name="author" content="Ondrej Svestka | ondrejsvestka.cz"> -->
	<meta name="keywords" content="Book store, Rent books">

	<title>
		Book Rental : Book Store
	</title>

	<meta name="keywords" content="Book store, Rent books">

	<link href='http://fonts.googleapis.com/css?family=Roboto:400,500,700,300,100' rel='stylesheet' type='text/css'>

	<!-- styles -->
	<link href="css/font-awesome.css" rel="stylesheet">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/animate.min.css" rel="stylesheet">
	<link href="css/owl.carousel.css" rel="stylesheet">
	<link href="css/owl.theme.css" rel="stylesheet">
	<link href="css/book_carousel.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<!-- theme stylesheet -->
	<link href="css/style.default.css" rel="stylesheet" id="theme-stylesheet">

	<!-- your stylesheet with modifications -->
	<link href="css/custom.css" rel="stylesheet">

	<script src="js/respond.min.js"></script>

	<link rel="shortcut icon" href="favicon.png">

	<script src="js/jquery.min.js"></script>


	<style type="text/css">
		#bg:hover{
			color: white;
			background-color: #4fbfa8;
		}
	</style>
</head>

<?php
// Database connection part
require("dbhelper.php");
?>

<body>
    <!-- *** NAVBAR ***
 _________________________________________________________ -->

    <div class="navbar navbar-default yamm" role="navigation" id="navbar">
        <div class="container">
            <div class="navbar-header">

                <a class="navbar-brand home" href="index.php" data-animate-hover="bounce">
                    <!-- <img src="img/logo.png" alt="Obaju logo" class="hidden-xs">
                    <img src="img/logo-small.png" alt="Obaju logo" class="visible-xs"><span class="sr-only">Obaju - go to homep age</span> -->
                    <h3 style="font-family: cursive;">E~<span style="color: #4fbfa8">Book</span>Rental</h3>
                </a>
            </div>
            <!--/.navbar-header -->

            <div class="navbar-collapse collapse right" id="navigation">

                <ul class="nav navbar-nav navbar-right">
                	<li class="active"><a href="index.php">Home</a></li> 
                    <li><a id="bg" href="register.php">Register/Login</a></li> 
                    <li class="dropdown yamm-fw">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="200">Category <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li>
                                <div class="yamm-content">
                                    <?php
                                       try{
                                          $sql = "SELECT categoryname FROM tblcategory group by categoryname";   
                                          $result = $pdo->query($sql);
                                          // $count=$result->rowCount();
                                          if($result->rowCount() > 0){  
                                             echo "<ul>";    
                                                while($row = $result->fetch()){ 
                                                   echo "<li><a style='font-size: 18px;' href='detail.php'>".$row['categoryname']."</a></li>";
                                                }     
                                             echo "</ul>";
                                          }else{
                                             echo "<h5>No categories</h5>";
                                          }
                                       } catch(PDOException $e){
                                          die("ERROR: Could not able to execute $sql. " . $e->getMessage());
                                       }
                                    ?>
                                </div>
                                <!-- /.yamm-content -->
                            </li>
                        </ul>
                    </li>
                    </ul>
                    
            </div>
            <!--/.nav-collapse -->

         
            <!--/.nav-collapse -->
        </div>
        <!-- /.container -->
    </div>
    <!-- /#navbar -->

    <!-- *** NAVBAR END *** -->

<div id="content">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<ul class="breadcrumb">
					<li><a href="index.php">Home</a>
					</li>
					<li>View more</li>
				</ul>
			</div>
		</div>
		
		<div class="row">
			<!-- <div class="col-md-1"></div> -->
			<div class="col-md-2">
				<div id="get_category"></div>
			</div>
			<div class="col-md-10">
				<div class="panel panel-primary">
					<div class="panel-heading">Books</div>
						<div class="panel-body">
							<div id="get_books"></div>
						</div>
						<!-- <div class="panel-footer">&copy; <script>document.write(new Date().getFullYear())</script> | E-BookRental, Online Book Store
						</div> -->
				</div>
			</div>
		</div>
			<div class="col-md-1"></div>

		</div>

          <!-- *** Books From Database  ***
   _________________________________________________________ -->
	
            </div> <!--row -->
         
     </div>  <!-- container -->


     </div>  <!-- content -->




<!-- *** COPYRIGHT ***
	_________________________________________________________ -->
	<?php
     	include('footer.php');
   	?>

	<!-- *** COPYRIGHT END *** -->

	<!-- /#all -->

</div>

<!-- My javasript ajax code -->
	<script src="js/myjs.js"></script>

<!-- *** SCRIPTS TO INCLUDE ***
	_________________________________________________________ -->
	<script src="js/jquery-1.11.0.min.js"></script>
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.cookie.js"></script>
	<script src="js/waypoints.min.js"></script>
	<script src="js/modernizr.js"></script>
	<script src="js/bootstrap-hover-dropdown.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/front.js"></script>
	<!-- My javasript ajax code -->
	<script src="js/myjs.js"></script>

</body>

</html>