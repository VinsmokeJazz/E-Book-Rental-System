<!DOCTYPE html>
<html lang="en">
<?php
include("header.php");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bookrent";

    //include("header1.php");
    try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo "connected";
}
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
<head>   
    <link rel="stylesheet" href="css/styles.css">  
</head>

<body>
    <!-- *** TOPBAR ***
 _________________________________________________________ -->
        <!-- *** NAVBAR ***
 _________________________________________________________ -->

    <div class="navbar navbar-default yamm " role="navigation" id="navbar">
        <div class="container">
            <div class="navbar-header">

                <a class="navbar-brand home" href="index.php" data-animate-hover="bounce">
                    <!-- <img src="img/logo.png" alt="Obaju logo" class="hidden-xs">
                    <img src="img/logo-small.png" alt="Obaju logo" class="visible-xs"><span class="sr-only">Obaju - go to homep age</span> -->
                    <h3 style="font-family: cursive;">E~<span style="color: #428bca">Book</span>Rental</h3>
                </a>
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation">
                        <span class="sr-only">Toggle navigation</span>
                        <i class="fa fa-align-justify"></i>
                </button>
                    
            </div>
            <!--/.navbar-header -->

            <div class="navbar-collapse collapse right" id="navigation">

                <ul class="nav navbar-nav navbar-right">
                    <li class="active"><a href="index.php">Home</a></li> 
                    <li><a id="bg" href="register.php">Register/Login</a></li> 
                    <li><a id="bg" href="category.php">Category</a></li>     
                </ul>
            </div>
            <!--/.nav-collapse -->
        </div>
        <!-- /.container -->
    </div>
    <!-- *** NAVBAR END *** -->


    <?php
        $bid=$_GET['bid'];
                            //echo $bid;
        $qry=$conn->prepare("SELECT b.bookid,b.bookname,b.author,b.category,b.course,b.bookdesc,b.price,b.stock,b.bookimage,b.book_keywords,cat.categoryname,cat.categoryid,c.courseid,c.coursename from tblbooks b,tblcategory cat,tblcourse c where cat.categoryid=b.category AND c.courseid=b.course AND bookid=".$bid);
        $qry->execute();
        if($qry->rowCount() > 0){
            while($row = $qry->fetch()){
                $cat=$row['course'];
                                   
    ?>

    <div id="all">
        <div id="content" >
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <ul class="breadcrumb">
                            <li><a href="index.php">Home</a>
                            </li>
                            <!-- <li><a href="category.php"><?php echo $row['categoryname']; ?></a>
                            </li>
                            <li><a href="category.php"><?php echo $row['coursename']; ?></a>
                            </li> -->
                            <li><a href="category.php">Category</a></li>
                            <li><?php echo $row['bookname']; ?></li>
                        </ul>
                    </div>
                </div>


                <div class="row">
                    <!-- <div class="col-md-2">
                        <div id="get_category"></div>
                    </div> -->
                    
                    <div class="col-md-10 col-sm-12 col-xs-12">
                        <div class="row" id="productMain">

                            <div class="col-sm-12 col-xs-12 col-md-5">
                                <div id="mainImage" >
                                   <?php echo "<img src=admin/book_images/". $row['bookimage'] ." alt='book' style='height: 400px;width:380px;' class='img-responsive'>"; ?>
                                </div>
                            </div>

                            <div class="col-sm-12 col-xs-12 col-md-6 ">
                                <div class="box">
                                    <h2 class="text-center"> <?php echo $row['bookname'] ?> </h2>
                                    
                                    <label><b>Author      : </b><?php echo $row['author'];?></label> <br>
                                    <label><b>Availability: </b><?php echo $row['stock'];?></label> <br>
                                    <label><b>Description : </b><?php echo $row['bookdesc'];?></label>
                                      
                                    <p class="price">₹<?php echo $row['price'];?></p>

                                    <p class="text-center buttons">
                                        <a href="customerbooks.php" class="btn btn-primary"><i class="fa fa-shopping-cart"></i> Add to cart</a> 
                                        <a href="customerbooks.php" class="btn btn-default"><i class="fa fa-heart"></i> Add to wishlist</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    <?php
            }
        }
    ?>
                   
            <div class="push"></div>
        </div> <!-- content -->

        
<!-- *** COPYRIGHT ***
   _________________________________________________________ -->
   <div id="copyright" style="">
      <div class="container">
         <div class="col-md-6">
            <p class="pull-left">      
               &copy; <script>document.write(new Date().getFullYear())</script> | E-BookRental, Online Book Store
            </p>
         </div>
      </div>
   </div>
   <!-- *** COPYRIGHT END *** -->

</div>
    <!-- /#all -->


    

    <!-- *** SCRIPTS TO INCLUDE ***
 _________________________________________________________ -->
    <script src="js/jquery-1.11.0.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.cookie.js"></script>
    <script src="js/waypoints.min.js"></script>
    <script src="js/modernizr.js"></script>
    <script src="js/bootstrap-hover-dropdown.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/front.js"></script>

    <!-- My javasript ajax code -->
    <script src="js/myjs.js"></script>

</body>

</html>