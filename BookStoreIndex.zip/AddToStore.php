<?php
	// Database connection part
	require("dbhelper.php");
	$num = $_GET['num'];
	
	if($num == 1){
		$userid= $_GET['cid'];
		$bookid=$_GET['bookid'];

		$sql=$pdo->prepare("INSERT INTO tbladdtostore(id,userid,bookid)VALUES(NULL,:userid,:bookid)");
		$sql->bindParam(':userid',$userid);
		$sql->bindParam(':bookid',$bookid);
		$result=$sql->execute();
		// if($result > 0){
		// 	header('location : customerbooks.php');
		// }
		header('location: customerbooks.php');
	}
?>