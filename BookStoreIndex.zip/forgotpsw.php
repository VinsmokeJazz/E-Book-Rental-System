
<?php
/* session_start();
	// echo "customer is ".$_SESSION["cid"];
if ($_SESSION["cid"] == NULL){
	header('location: register.php');
}
$userID = $_SESSION["cid"];
		// Database connection part */
require("dbhelper.php");
?>

<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>

	<?php
	if(isset($_POST['reset'])){
		$email=$_POST['eid'];
		$npsw=$_POST['npsw'];
			// $cpsw=$_POST['cpsw'];

			// if((strlen($npsw)>=8) && (strlen($cpsw)>=8)){
			// 	if($npsw==$cpsw){
		$sql1=$pdo->prepare("SELECT * from tblusers WHERE email=:email");
		$sql1->execute(["email"=>$email]);
		if($sql1->rowCount()>0){
			$sql=$pdo->prepare("UPDATE tblusers SET password=:npsw WHERE email=:email");
			$sql->execute(["npsw"=>$npsw,"email"=>$email]);
			echo '<script type="text/javascript">'; 
			echo 'alert("Successfully Updated");'; 
			echo 'window.location.href = "register.php";';
			echo '</script>';
		}else{
			echo '<script type="text/javascript">'; 
			echo 'alert("email does not exist");'; 
			echo 'window.location.href = "register.php";';
			echo '</script>';
		} 
				// }else{
				// 	echo '<script type="text/javascript">'; 
				// 	echo 'alert("New Password and ConfirmPassword must match!!!");'; 
				// 	echo 'window.location.href = "register.php";';
				// 	echo '</script>';
				// }
			// }else{
			// 	echo '<script type="text/javascript">'; 
			// 	echo 'alert("Password length must be greterthan 8 ");'; 
			// 	echo 'window.location.href = "register.php";';
			// 	echo '</script>';
			// }
	}

	?>
</body>
<script src="js/validation.js"></script>
</html>

