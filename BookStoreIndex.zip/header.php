<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="robots" content="all,follow">
  <meta name="googlebot" content="index,follow,snippet,archive">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Book Store Rental system">
  <!-- <meta name="author" content="Ondrej Svestka | ondrejsvestka.cz"> -->
  <meta name="keywords" content="Book store, Rent books">

  <link rel="shortcut icon" href="img/booklogo.png"/>

  <title>
    Book Rental : Book Store
  </title>

  <meta name="keywords" content="Book store, Rent books">

  <link href='http://fonts.googleapis.com/css?family=Roboto:400,500,700,300,100' rel='stylesheet' type='text/css'>

  <!-- styles -->
  <link href="css/font-awesome.css" rel="stylesheet">
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/animate.min.css" rel="stylesheet">
  <link href="css/owl.carousel.css" rel="stylesheet">
  <link href="css/owl.theme.css" rel="stylesheet">
  <link href="css/book_carousel.css" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet">
  <!-- theme stylesheet -->
  <link href="css/style.default.css" rel="stylesheet" id="theme-stylesheet">

  <!-- your stylesheet with modifications -->
  <link href="css/notification.css" rel="stylesheet">
  <link href="css/custom.css" rel="stylesheet">
  <link href="css/jquery-ui.css" rel="stylesheet">

  <script src="js/respond.min.js"></script>

  <style type="text/css">
    .mainpagebg {
      background: url("img/book2slider.jpg") no-repeat center fixed;
      background-size: cover;
      position: relative;
    }
    .mainpagebg .overlay {
      background: rgba(238, 238, 238, 0.85);
    }
    .inline{
      display: inline;
    }
    #bg:hover{
      color: white;
      background-color: #428bca;
    }
    #user:hover{
      color: #428bca;
    }
    #cart_container:hover{
      color: white;
      background-color: #428bca;
    }
    html, body {
      height: 100%;
      margin: 0;
    }
    #content {
      padding: 20px;
      min-height: 100%;
      margin: 0 auto -50px;
    }
    #copyright,
    .push {
      height: 50px;
    }      
    .books {
      background: url("img/book2slider.jpg") no-repeat center fixed;
      background-size: cover;
      position: relative;
    }
    .books .overlay {
      background: rgba(238, 238, 238, 0.55);
    }
    .challanidbox {
      /* background: #fff; */
      margin: 0 0 30px;
      border: solid 3px #428bca;
      -webkit-box-sizing: border-box;
      -moz-box-sizing: border-box;
      box-sizing: border-box;
      padding: 9px;
      -webkit-box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);
      box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);
    }

    /*@media screen and (min-width: 768px){*/
      .dropdown:hover .dropdown-menu, .btn-group:hover .dropdown-menu{
        display: block;
      }
      /*.dropdown-menu{
        margin-top: 0;
      }
      .dropdown-toggle{
        margin-bottom: 2px;
      }
      .navbar .dropdown-toggle, .nav-tabs .dropdown-toggle{
        margin-bottom: 0;
      }*/
    /*}*/
  </style>
</head>

<body>


</body>
</html>