<?php
	// Database connection part
require("dbhelper.php");

//Code to display all the categories in side navigation before login
if(isset($_POST["category"])){
	try{
		$category_query = "SELECT * FROM tblcategory GROUP BY(categoryname)";
		$result = $pdo->query($category_query);

		echo "<div class='nav nav-pills nav-stacked' style='border: 1px solid #428bca;''><li class='active'><a><h4>Categories</h4></a></li>";

		if($result->rowCount() > 0){                                       
			while($row = $result->fetch()){ 
				$catid= $row["categoryid"];
				$catname = $row['categoryname'];
				
				echo "<li class='container'>";
				echo "<h5>$catname</h5>";

				$course_query="SELECT courseid,coursename,category FROM tblcourse  where category= ".$catid;
				$result1 = $pdo->query($course_query);
				
				if($result1->rowCount() > 0){        
					
					echo "<ul class='fa-ul'>";                             
					while($row1 = $result1->fetch()){ 
						$courseid=$row1['courseid'];
						$course=$row1['coursename'];	
						echo "<li><i class='fa-li fa fa-check'></i><a href='#' class='course'  cid='$courseid' > $course</a></li>";
					}
					echo "</ul>";
			    }
					
				echo "</li>";
			} 
			echo "</div>";    
		}else{
			echo "<h5>No categories</h5>";
		}
	} catch(PDOException $e){
		die("ERROR: Could not able to execute $sql. " . $e->getMessage());
	}
}

if(isset($_POST["book"])){
	try{
		$book_query = "SELECT b.bookid,b.category,b.course,b.bookname,b.bookimage,b.author,b.price,b.stock,c.courseid,c.coursename,cat.categoryid,cat.categoryname FROM tblbooks b,tblcategory cat,tblcourse c WHERE b.category=cat.categoryid AND b.course=c.courseid";
			// ORDER BY RAND() 
		$result = $pdo->query($book_query);

		if($result->rowCount() > 0){

			?>

			<!-- <div class="row"> -->

			<?php        
			while($row = $result->fetch()){ 
				$bid=$row['bookid'];
				echo "<div class='col-md-4 '>";
				echo "<div class='panel panel-primary' align='center'>";
				echo "<div class='panel-heading'>";
				echo "<a href='detail.php?bid=$bid'><img src='admin/book_images/".$row['bookimage']."' style='height: 200px;width:150px;padding-top: 10px;' alt='' class='img-responsive'></a>";
				echo "</div>";
				echo "<div class='panel-body' align='center'>";
				echo "<h5 style='text-align:center;'>".$row['coursename']."</h5>";
				echo "<h5 style='text-align:center;'>".$row['bookname']."</h5>";
				echo "<h5 style='text-align:center;'>Rs.".$row['price']."</h5>";
				echo "</div>";
				echo "<div class='panel-footer'>";
				if($row['stock'] > 0){
					echo "<a href='customerbooks.php' class='btn btn-primary '><i class='fa fa-shopping-cart'></i> Add to cart</a> 
                    <a href='customerbooks.php' class='btn btn-default '><i class='fa fa-heart'></i> </a>";
				}else{
					echo "<h6 style='text-align:center;color:red;'><b>Book Not Avaliable</b></h6>";
				}
				echo "</div>";
				echo "</div>";
				echo "</div>";
			}

		} else {
			echo "<h3 style='text-align: center;'>No Book Details</h3>";
		}
	} catch(PDOException $e){
		die("ERROR: Could not able to execute $sql. " . $e->getMessage());
	}
}                               

//Code for getting books by selecting particular course and also code for search using keywords 
if(isset($_POST["getSelectedCourse"]) || isset($_POST["search"])){
	if(isset($_POST["getSelectedCourse"])) {
		$crsid = $_POST["course_id"];
		$crsselectedquery = $pdo->prepare("SELECT b.bookid,b.course,b.bookname,b.bookimage,b.author,b.price,b.stock,c.courseid,c.coursename FROM tblbooks b,tblcourse c WHERE b.course=:crsid AND b.course=c.courseid");
		$crsselectedquery->execute(["crsid"=>$crsid]);
	}else if(isset($_POST["search"])){
		$keywords = $_POST["keywords"];
		$crsselectedquery = $pdo->prepare("SELECT b.bookid,b.course,b.bookname,b.bookimage,b.author,b.price,b.stock,b.book_keywords,c.courseid,c.coursename FROM tblbooks b,tblcourse c WHERE b.course=c.courseid AND b.book_keywords LIKE :keywords");
		$crsselectedquery->execute(array(':keywords' => "%".$keywords."%"));
	}	
	
	try{
    	if($crsselectedquery->rowCount() > 0){      
			while($row = $crsselectedquery->fetch()){ 
				$bookid=$row['bookid'];
				echo "<div class='col-md-4 '>";
					echo "<div class='panel panel-primary' align='center'>";

						echo "<div class='panel-heading'>";
							echo "<a href='detail.php?bid=$bookid'><img src='admin/book_images/".$row['bookimage']."' style='height: 200px;width:150px;padding-top: 10px;' alt='' class='img-responsive'></a>";
						echo "</div>";
						echo "<div class='panel-body' align='center'>";
							echo "<h5 style='text-align:center;'>".$row['coursename']."</h5>";
							echo "<h5 style='text-align:center;'>".$row['bookname']."</h5>";
							echo "<h5 style='text-align:center;'>Rs.".$row['price']."</h5>";
						echo "</div>";
						echo "<div class='panel-footer'>";
						if($row['stock'] > 0){
							echo "<a href='customerbooks.php' class='btn btn-primary '><i class='fa fa-shopping-cart'></i> Add to cart</a> 
                    		<a href='customerbooks.php' class='btn btn-default '><i class='fa fa-heart'></i> </a>";
						}else{
							echo "<h5 style='text-align:center;'>Book Not Avaliable</h5>";
						}
						echo "</div>";
					echo "</div>";
				echo "</div>";
			}

		} else {
			echo "<h3 style='text-align: center;'>No Book Details</h3> ";
		}
	} catch(PDOException $e){
		die("ERROR: Could not able to execute  " . $e->getMessage());
	}
}

?>