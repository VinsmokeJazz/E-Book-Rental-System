<?php
	if(isset($_POST["login"]))
    {
        $uname = $pass = "";
        // $NameError = $EmailError = $AddressError= "";
        $uname = $_POST["txtUname"];
        $pass = $_POST["txtPassword"];
        $cID = $aID = 0;
        $CustCheck = $AdminCheck = false;

        // Start the session
		session_start();

		$servername = "localhost";
        $username = "root";
   	    $password = "";
   	    $dbname = "bookrent";

        try{
            $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            // set the PDO error mode to exception
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $stmt = $conn->prepare("SELECT userid,name FROM tblusers WHERE username=:username and password=:pass");
            $stmt->bindParam(':username',$uname);
            $stmt->bindParam(':pass',$pass);
            $stmt->execute();

            $res = $stmt->fetch(PDO::FETCH_ASSOC);

            if($res){
                $CustCheck = true;
                $cID = $res["userid"];
                $name= $res["name"];
                $_SESSION["cid"] = $cID;
                $_SESSION["name"] = $name;
            }else{
              	$CustCheck = false;
            }

            if($CustCheck == false){
              	$stmt = $conn->prepare("SELECT adminid FROM tbladmin WHERE username=:username and password=:pass");
	            $stmt->bindParam(':username',$uname);
                $stmt->bindParam(':pass',$pass);
	            $stmt->execute();

	            $res = $stmt->fetch(PDO::FETCH_ASSOC);

                if($res){
	                $AdminCheck = true;
	                $aID = $res["adminid"];
	                $_SESSION["admid"] = $aID;
	            }else{
                	$AdminCheck = false;
                }
			}
			if($CustCheck == true){
				header('location: customerbooks.php');
			}else if($AdminCheck == true){
				header('location: admin/index.php');
			}else{
				header('location: register.php?wrongid=1');
			}
		}catch(PDOException $e){
            echo "ERROR: ".$e->getMessage();
        }
        $conn = null;
    }
?>
