/* Collapsing and expanding paragraphs  */
$(function(){
    $("#Email").blur(function() {
        var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;  
        var emailaddress = $("#Email").val();
        if(!emailReg.test(emailaddress)) 
            $("#emailerrormsg").html('<font color="red">Please enter valid Email address</font>');  
        else
            $("#emailerrormsg").html('<font color="#cc0000"></font>');  
    });
	
	$("#email").blur(function() {
        var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;  
        var emailaddress = $("#email").val();
        if(!emailReg.test(emailaddress)) 
            $("#emailerror").html('<font color="red">Please enter valid Email address</font>');  
        else
            $("#emailerror").html('<font color="#cc0000"></font>');  
    });

	$("#name").blur(function(){
		var nameReg = /^[a-zA-Z ]+$/;
		var nameText = $("#name").val();
		if(!nameReg.test(nameText))
			$("#nameerrormsg").html('<font color="red">Name can contain only Letters</font>'); 
		else
			$("#nameerrormsg").html('<font color="#cc0000"></font>'); 
	});
	
	$("#Phone").on("blur", function(){
        var mobNum = $(this).val();
        var filter = /^\d*(?:\.\d{1,2})?$/;

        if (filter.test(mobNum)) {
            if(mobNum.length==10){
				$("#phoneerrormsg").html('<font color="#cc0000"></font>');
            } else {
                $('#phoneerrormsg').html('Enter 10 digit Valid Phone Number');
				$('#phoneerrormsg').css('color', 'red');
                return false;
            }
        }else{
            $('#phoneerrormsg').html('Invalid Number');
			$('#phoneerrormsg').css('color', 'red');
            return false;
        }
	});
	
	$("#password").blur(function(){
		var password = $("#password").val();
		if(password.length < 8){
			$("#passworderrormsg").html('<font color="red">Password must have 8 or more characters long..!</font>'); 
		}else{
			$("#passworderrormsg").html('<font color="#cc0000"></font>'); 
		}
	});
	$("#pass").blur(function(){
        var password = $("#pass").val();
        if(password.length < 8){
            $("#passworderror").html('<font color="red">Password must have 8 or more characters long..!</font>'); 
        }else{
            $("#passworderror").html('<font color="#cc0000"></font>'); 
         }
    });
});
/* ------------------------------------------------------ */
	
/* Hide navbar onclick of the dropdown contents   */
$(document).ready(function () {
	$(".nav li a").click(function(event) {
		$(".collapse").collapse('hide');
	});
});
/*-----------------------------------------------------*/

/* NAvigation Shrink */
$(window).scroll(function(){
	if($(document).scrollTop() > 50 ){
		$('nav').addClass('shrink');
	}else{
		$('nav').removeClass('shrink');
	}
});
/* -------------------------- */