$(document).ready(function(){
	// Display category before Login
	category();
	function category(){
		$.ajax({
			url : "action.php",
			method : "POST",
			data : {category:1},
			success : function(data){
				$("#get_category").html(data);
			}
		})
	}
	
	// Display Product before Login
	book();
	function book(){
		$.ajax({
			url : "action.php",
			method : "POST",
			data : {book:1},
			success : function(data){
				$("#get_books").html(data);
			}
		})
	}
	
	// before Login
	$("body").delegate(".category","click",function(event){
		event.preventDefault();
		var catid = $(this).attr('cid');
		$.ajax({
			url : "action.php",
			method : "POST",
			data : {getSelectedCategory:1,cat_id:catid},
			success : function(data){
				$("#get_books").html(data);
			}
		})
	})
	
	//Display course based on selection
	$("body").delegate(".course","click",function(event){
		event.preventDefault();
		var crsid = $(this).attr('cid');
		$.ajax({
			url : "action.php",
			method : "POST",
			data : {getSelectedCourse:1,course_id:crsid},
			success : function(data){
				$("#get_books").html(data);
			}
		})
	})
	
	// $("#searchbtn").click(function(){
	// 	var keywords= $("#search").val();
	// 	if(keywords != ""){
	// 		$.ajax({
	// 			url : "action.php",
	// 			method : "POST",
	// 			data : {search:1,keywords:keywords},
	// 			success : function(data){
	// 				$("#get_books").html(data);
	// 			}
	// 		})
	// 	}
	// })
	$("#search").keyup(function(){
		var keywords= $("#search").val();
		if(keywords != ""){
			$.ajax({
				url : "action.php",
				method : "POST",
				data : {search:1,keywords:keywords},
				success : function(data){
					$("#get_books").html(data);
				}
			})
			}else if(keywords == ""){
			$.ajax({
				url : "action.php",
				method : "POST",
				data : {book:1},
				success : function(data){
					$("#get_books").html(data);
				}
			})
		}
	})
	
	$("#searchToggle").keyup(function(){
		var keywords= $("#searchToggle").val();
		if(keywords != ""){
			$.ajax({
				url : "action.php",
				method : "POST",
				data : {search:1,keywords:keywords},
				success : function(data){
					$("#get_books").html(data);
				}
			})
			}else if(keywords == ""){
			$.ajax({
				url : "action.php",
				method : "POST",
				data : {book:1},
				success : function(data){
					$("#get_books").html(data);
				}
			})
		}
	})
	// -------------After Login--------------------------------------------------------
	
	// Display category before Login
	login_category();
	function login_category(){
		$.ajax({
			url : "login_action.php",
			method : "POST",
			data : {category:1},
			success : function(data){
				$("#login_get_category").html(data);
			}
		})
	}
	
	// Display books After Login
	login_getbook();
	function login_getbook(){
		$.ajax({
			url : "login_action.php",
			method : "POST",
			data : {book:1},
			success : function(data){
				$("#login_get_books").html(data);
			}
		})
	}
	
	// After Login
	$("body").delegate(".category","click",function(event){
		event.preventDefault();
		var catid = $(this).attr('cid');
		$.ajax({
			url : "login_action.php",
			method : "POST",
			data : {getSelectedCategory:1,cat_id:catid},
			success : function(data){
				$("#login_get_books").html(data);
			}
		})
	})
	
	$("#LoginSearch").keyup(function(){
		var keywords= $("#LoginSearch").val();
		if(keywords != ""){
			$.ajax({
				url : "login_action.php",
				method : "POST",
				data : {search:1,keywords:keywords},
				success : function(data){
					$("#login_get_books").html(data);
				}
			})
		}else if(keywords == ""){
			$.ajax({
				url : "login_action.php",
				method : "POST",
				data : {book:1},
				success : function(data){
					$("#login_get_books").html(data);
				}
			})
		}
	})
	
	$("#LoginSearchToggle").keyup(function(){
		var keywords= $("#LoginSearchToggle").val();
		if(keywords != ""){
			$.ajax({
				url : "login_action.php",
				method : "POST",
				data : {search:1,keywords:keywords},
				success : function(data){
					$("#login_get_books").html(data);
				}
			})
		}else if(keywords == ""){
			$.ajax({
				url : "login_action.php",
				method : "POST",
				data : {book:1},
				success : function(data){
					$("#login_get_books").html(data);
				}
			})
		}
	})
	//Display books based on category
	$("body").delegate(".category","click",function(event){
		event.preventDefault();
		var catid = $(this).attr('cid');
		$.ajax({
			url : "login_action.php",
			method : "POST",
			data : {getSelectedCategory:1,cat_id:catid},
			success : function(data){
				$("#login_get_books").html(data);
			}
		})
	})
	
	//Display book details based on clicked book images
	$("body").delegate(".bookdetails","click",function(event){
		event.preventDefault();
		var bookid = $(this).attr('bid');
		$.ajax({
			url : "login_action.php",
			method : "POST",
			data : {getbookdetails:1,b_id:bookid},
			success : function(data){
				$("#login_get_books").html(data);
			}
		})
	})
	
	//Display books based on course
	$("body").delegate(".course","click",function(event){
		event.preventDefault();
		var crsid = $(this).attr('cid');
		$.ajax({
			url : "login_action.php",
			method : "POST",
			data : {getSelectedCourse:1,course_id:crsid},
			success : function(data){
				$("#login_get_books").html(data);
			}
		})
	})
	
	cart_count();
	$("body").delegate("#book","click",function(event){
		event.preventDefault();
		var bid = $(this).attr('bookid');
		// var mesg = $(this).attr('bid');
		$.ajax({
			url : "login_action.php",
			method : "POST",
			data : {addToStore:1,bookid:bid},
			success : function(msg){
				if(msg == 0){
					alert('Book already added to Cart, Continue Shopping');
					// $(".bookval-"+bid).prop("disabled",true);
					// $(".bookval-"+bid).text("Already added");
				}else{
					// $('#added').html('<div class="alert alert-success alert-dismissable fade in"><a href="category_course.php" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success!</strong> <p align="center" style="font-family: cursive;color: black">Successfully Registered..!</p></div>');
					// alert('Book is added to store..!');
					// $(this).attr('bookid').value('added');
					$(".bookval-"+bid).prop("disabled",true);
					$(".bookval-"+bid).text("Book added");
					cart_count();
				}
			}
		})
	})
	
	cart_container();
	function cart_container(){
		$.ajax({
			url : "login_action.php",
			method : "POST",
			data : {get_cart_books:1},
			success : function(data){
				$("#cart_books").html(data);
			}
		})   
	} 
	
	function cart_count(){
		$.ajax({
			url : "login_action.php",
			method : "POST",
			data : {cart_count:1},
			success : function(data){
				$(".cartbadge").html(data);
			}
		})
	} 
	
	/* $("#cart_container").click(function(event){
		event.preventDefault();
		$.ajax({
			url : "login_action.php",
			method : "POST",
			data : {get_cart_books:1},
			success : function(data){
				$("#cart_books").html(data);
			}
		})
	}) */
	
	
	function wishlist_count(){
		$.ajax({
			url : "login_action.php",
			method : "POST",
			data : {wishlist_count:1},
			success : function(data){
				$(".wishlistbadge").html(data);
			}
		})
	}
	
	page();
	function page(){
		$.ajax({
			url : "login_action.php",
			method : "POST",
			data : {page:1},
			success:function(data){
				$("#pageno").html(data);
			}
		})
	}
	
	//Pagination ajax to display all the books
	// $("body").delegate("#page","click",function(){
	// 	var pagenum=$(this).attr("page");
	// 	// alert(pagenum);
	// 	$.ajax({
	// 		url : "login_action.php",
	// 		method : "POST",
	// 		data : {book:1,setpage:1,pagenumber:pagenum},
	// 		success:function(data){
	// 			$("#login_get_books").html(data);
	// 		}
	// 	})
	// })
	
	//Pagination ajax to display selected course books
	// $("body").delegate("#page","click",function(){
	// 	var pagenum=$(this).attr("page");
	// 	var course=$(this).attr("course_id");
	// 	$.ajax({
	// 		url : "login_action.php",
	// 		method : "POST",
	// 		data : {getSelectedCourse:1,setpage:1,pagenumber:pagenum,course_id:course},
	// 		success:function(data){
	// 			$("#login_get_books").html(data);
	// 		}
	// 	})
	// })
	
	// -----------------To display all the details in Store.php ---------------------
	storecheckout();
	function storecheckout(){
		$.ajax({
			url : "login_action.php",
			method : "POST",
			data : {getstorecheckout:1},
			success:function(data){
				$("#storecheckout").html(data);
				NumOfRecords();
				/* $(".update").hides(); */
			}
		})
	}
	
	function NumOfRecords(){
		$.ajax({
			url : "login_action.php",
			method : "POST",
			data : {getNumOfRecords:1},
			success:function(data){
				$("#NumOfRecords").html(data);
			}
		})
	}
	
	$("body").delegate(".qty","change",function(){
		var bookid=$(this).attr('bid');
		var qty = $("#qty-"+bookid).val();
		var price=$("#price-"+bookid).val();
		var total= qty * price;
		var stock=$("#stock-"+bookid).val();
		$("#total-"+bookid).val(total);
		 $.ajax({
			url:"login_action.php",
			method: "POST",
			data:{updatestore:1,updateid:bookid,qty:qty,total:total},
			success:function(data){
				if(data == 1){ 
					/*document.getElementById("moreqty-"+bookid).style.display = "";
					$("#moreqty-"+bookid).text("Available stock is "+stock+ ". Please Reduce the Quantity.");*/
					alert("Available stock is "+stock);
					storecheckout();
				}else{
					storecheckout();
					NumOfRecords();
				}
			}
		}) 
	}); 
	
 	/* $("body").delegate(".qty","blur",function(){
		var bookid=$(this).attr('bid');
		var qty = $("#qty-"+bookid).val();
		var price=$("#price-"+bookid).val();
		var total= qty * price;
		$("#total-"+bookid).val(total);
	});  */ 
	
	$("body").delegate(".delete","click",function(){
		var bookid=$(this).attr('deleteid');
		$.ajax({
			url : "login_action.php",
			method : "POST",
			data :{deletefromstore:1,deleteid:bookid},
			success:function(data){
				// $('#display_store_message').html(data);
				storecheckout();
			}
		})
	})
	
	$("body").delegate(".update","click",function(){
		var bookid=$(this).attr('updateid');
		var qty=$("#qty-"+bookid).val();
		var price=$("#price-"+bookid).val();
		var total=$("#total-"+bookid).val();
		var stock=$("#stock-"+bookid).val(); 
		$.ajax({
			url : "login_action.php",
			method : "POST",
			data :{updatefromstore:1,updateid:bookid,qty:qty,price:price,total:total},
			success:function(data){
				if(data == 1){ 
					/*document.getElementById("moreqty-"+bookid).style.display = "";
					$("#moreqty-"+bookid).text("Available stock is "+stock+ ". Please Reduce the Quantity.");*/
					alert("Available stock is "+stock);
					storecheckout();
				}else{
					/* document.getElementById("moreqty-"+bookid).style.display = "none"; */
					storecheckout(); 
					NumOfRecords()
				} 
				/* if(data == 1){
					alert("Available stock is "+stock);
					$("#qty-"+bookid).val(1);
				} */
				/* }else{
					$('#display_store_message').html('<div class="alert alert-success alert-dismissable fade in "><a href="index.php" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success..!</strong><br> <p align="center" >Quantity of book is been updated. Continue Shopping..!</p></div>');
					storecheckout();
					NumOfRecords();
				}   */
			}
		})
	})
	// --------------------End of store.php page-------------------------
	
	/* ------------------Wishlist.php ------------------------------------- */
	wishlist_count();
	$("body").delegate("#bookwishlist","click",function(event){
		event.preventDefault();
		/* alert('inside the function'); */
		var bid = $(this).attr('bookid');
		// var mesg = $(this).attr('bid');
		$.ajax({
			url : "login_action.php",
			method : "POST",
			data : {addToWishlist:1,bookid:bid},
			success : function(msg){
				if(msg == 0){
					alert('Book already added to wishlist, Continue Shopping');
					// $(".bookval-"+bid).prop("disabled",true);
					// $(".bookval-"+bid).text("Already added");
				}else{
					// $('#added').html('<div class="alert alert-success alert-dismissable fade in"><a href="category_course.php" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Success!</strong> <p align="center" style="font-family: cursive;color: black">Successfully Registered..!</p></div>');
					// alert('Book is added to store..!');
					// $(this).attr('bookid').value('added');
					$(".bukval-"+bid).prop("disabled",true);
					/* $(".bookval-"+bid).text("Book added"); */
					wishlist_count(); 
				}
			}
		})
	}) 
	
	//wishlist
	wishlist_avail();
	function wishlist_avail(){
		$.ajax({
			url: "login_action.php",
			type: "POST",
			//processData:false,
			data :{wishlist_avail:1},
			success: function(data){
				if(data > 0){
					$(".notification").remove();	
					$("#notification-latest").show();
					$("#notification-latest").html(data);
				}else{
					$("#notification-latest").hide();
					$(".notification").hide();
				}
			}
		});
	}
	
	//Add to cart from wishlist
	$("body").delegate("#wishlistbook","click",function(event){
		event.preventDefault();
		var bid = $(this).attr('bookid');
		// var mesg = $(this).attr('bid');
		$.ajax({
			url : "login_action.php",
			method : "POST",
			data : {addToCartFromWL:1,bookid:bid},
			success : function(msg){
				if(msg == 0){
					alert('Book already added to Cart, Continue Shopping');
					// $(".bookval-"+bid).prop("disabled",true);
					// $(".bookval-"+bid).text("Already added");
				}else{
					window.location.href="wishlist.php";
				}
			}
		})
	})
	
	//Delete from wishlist
	$("body").delegate(".deletewish","click",function(){
		/* alert("inside delete wish"); */
		var bookid=$(this).attr('delete_id');
		$.ajax({
			url : "login_action.php",
			method : "POST",
			data :{deletefromswishlist:1,delete_id:bookid},
			success:function(data){
				// $('#display_store_message').html(data);
				window.location.href="wishlist.php";	
			}
		}) 
	})
	
	/* -----------------------End of wishlist------------------------------------------- */
	
	// To display details in order review page i.e.placeorder.php
	orderreview();
	function orderreview(){
		$.ajax({
			url : "login_action.php",
			method : "POST",
			data : {getorderreview:1},
			success:function(data){
				$("#orderreview").html(data);
			}
		})
	}
	
	// -------------------On click of placeorder.php page, check if total qty greater than 15--------------------------
	$("body").delegate(".checkqty","click",function(){
		var sumqty=$("#sum").val();
		$.ajax({
			url : "login_action.php",
			method : "POST",
			data :{sumqtyfn:1,sumqty:sumqty},
			success:function(data){
				if(data>15){
					alert("Total quantity must be less than 15");
				}else{
					window.location.href="placeorder.php";
				} 
			}
		})
	}) 
	
	//--------------- My Account Edit -----------------------
	editdetal();
	function editdetal(){
		$.ajax({
			url : "login_action.php",
			method : "POST",
			data : {getuserdetails:1},
			success:function(data){
				$("#editdetal").html(data);
			}
		})
	}
	
	//------------------------------ Edit My Account Details ----------------------------------------
	$("body").delegate(".edits","click",function(){
		var name=$("#name").val();
		var num=$("#num").val();
		var address=$("#addr").val();
		var mail=$("#mail").val();
		var usern=$("#usern").val();
		var pass=$("#pass").val();
		$.ajax({
			url : "login_action.php",
			method : "POST",
			data :{editacc:1,name:name,num:num,addr:address,mail:mail,usern:usern,pass:pass},
			success:function(data){
				if(data==1){
					alert("Successfully Updated");
				}else{
					alert("Failed Update!!!Check with name and phone number");
					window.href="myaccount.php";
				} 
			}
		})
	})
});